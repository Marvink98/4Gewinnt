package controller;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import db.DBException;
import db.DBOperations;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
import main.Difficulty;
import main.GameVariant;
import model.Computer;
import model.Game;
import model.Player;
import view.ConfigGameView;
import view.GameMenuView;
import view.PVCView;
import view.PVPView;

public class GameMenuController {
    private Stage stage;
    private GameMenuView gameMenuView;
    private GameController gameController;
    private ObservableList<Game> fullHighscoreList;
    private ObservableList<Game> filteredHighscoreList;

    public GameMenuController(GameMenuView gameMenuView, Stage stage) {
        this.gameMenuView = gameMenuView;
        this.stage = stage;
        
        initViewEvents();
        this.filteredHighscoreList = this.gameMenuView.getHighscoreView().getItems();
        loadHighscoreList();
    }

    private void initViewEvents() {
        this.gameMenuView.getConfigView().getStartGameBtn().setOnAction(event -> {
            createGame();
        });

        registerFilterOnActionEvents();
    }

    private void loadHighscoreList() {
        try {
            DBOperations.createTable();
            this.fullHighscoreList = DBOperations.getFilteredGamesList();
            this.filteredHighscoreList.clear();
            this.filteredHighscoreList.addAll(this.fullHighscoreList);
            configureFilterHighscoreList();

        } catch (DBException e) {
            e.printStackTrace();
        }
    }

    private void registerFilterOnActionEvents() {
        this.gameMenuView.getConfigView().getGameVariantGrp().selectedToggleProperty().addListener(o -> {
            configureFilterHighscoreList();
        });
        
        this.gameMenuView.getConfigView().getTimeLimitCbx().selectedProperty().addListener(o -> {
            configureFilterHighscoreList();
        });
        this.gameMenuView.getConfigView().getModeTabPane().getSelectionModel().selectedItemProperty().addListener(o -> {
            configureFilterHighscoreList();
        });
        this.gameMenuView.getConfigView().getPvcView().getDifficultyGrp().selectedToggleProperty().addListener(o -> {
            configureFilterHighscoreList();
        });
    }

    private void configureFilterHighscoreList() {
        Predicate<Game> gameVariant = game -> {
            if (game.getGAME_VARIANT().equals((GameVariant) this.gameMenuView.getConfigView().getGameVariantGrp()
                    .getSelectedToggle().getUserData())) {
                return true;
            }
            return false;
        };
        
        Predicate<Game> withTimeLimit = game -> {
            if (game.getWithTimeLimit().getValue().equals(this.gameMenuView.getConfigView().getTimeLimitCbx().isSelected())) {
                return true;
            }
            return false;
        };
        
        Predicate<Game> gameMode = null;

        if (this.gameMenuView.getConfigView().getModeTabPane().getSelectionModel()
                .getSelectedItem() instanceof PVPView) {
            gameMode = game -> {

                if (game.getDIFFICULTY() == Difficulty.NONE) {
                    return true;
                }
                return false;
            };
        } else {
            gameMode = game -> {
                Difficulty gameDifficulty = game.getDIFFICULTY();
                Difficulty selectedDifficulty = (Difficulty) this.gameMenuView.getConfigView().getPvcView().getDifficultyGrp().getSelectedToggle().getUserData();
                if (gameDifficulty.equals(selectedDifficulty)) {
                    return true;
                }
                return false;
            };
        }
        
        
        
        filterHighscoreList(gameVariant, withTimeLimit, gameMode);
    }

    private void filterHighscoreList(Predicate<Game> gameVariant, Predicate<Game> withTimeLimit, Predicate<Game> gameMode) {
        Predicate<Game> filterComputerWinner = game -> {
            if (game.getWinner() instanceof Computer) {
                return false;
            }
            return true;
        };
        
        List<Game> filteredList = this.fullHighscoreList.stream()
                .filter(filterComputerWinner)
                .filter(gameVariant)
                .filter(withTimeLimit)
                .filter(gameMode)
                .collect(Collectors.toList());
        this.filteredHighscoreList.clear();
        this.filteredHighscoreList.addAll(filteredList);
    }

    /*
     * Create GameController and hand over configured Game and the
     * GameMenuController itself, in order to get notified if the GameController
     * ends (onGameEnded)
     */
    private void createGame() {
        ConfigGameView configView = this.gameMenuView.getConfigView();
        GameVariant selectedGameVariant = (GameVariant) configView.getGameVariantGrp().getSelectedToggle()
                .getUserData();
        Tab selectedGameModeTab = configView.getModeTabPane().getSelectionModel().getSelectedItem();
        boolean withTimeLimit = configView.getTimeLimitCbx().isSelected();
        Difficulty selectedDifficulty = Difficulty.NONE;
        Player playerOne = null;
        Player playerTwo = null;

        if (selectedGameModeTab instanceof PVPView) {
            TextField playerOneTxf = ((PVPView) selectedGameModeTab).getNamePlayerOneTxF();
            playerOne = playerOneTxf.getText().isEmpty() ? new Player("Player 1")
                    : new Player(playerOneTxf.getText().trim());
            TextField playerTwoTxf = ((PVPView) selectedGameModeTab).getNamePlayerTwoTxF();
            playerTwo = playerTwoTxf.getText().isEmpty() ? new Player("Player 2")
                    : new Player(playerTwoTxf.getText().trim());
        } else if (selectedGameModeTab instanceof PVCView) {
            TextField playerOneTxf = ((PVCView) selectedGameModeTab).getNamePlayerOneTxF();
            playerOne = playerOneTxf.getText().isEmpty() ? new Player("Human")
                    : new Player(playerOneTxf.getText().trim());
            playerTwo = new Computer();

            if (!isValidPlayerName(playerOne.getName(), playerTwo.getName())) {
                Alert playerNameErr = new Alert(AlertType.ERROR, "Spielername darf nicht gleich Computername sein");
                playerNameErr.showAndWait();
                return;
            }

            selectedDifficulty = (Difficulty) ((PVCView) selectedGameModeTab).getDifficultyGrp().getSelectedToggle()
                    .getUserData();
        } else {
            return;
        }

        Game newGame = new Game(selectedDifficulty, selectedGameVariant, withTimeLimit, playerOne, playerTwo);

        switch (selectedGameVariant) {
        case CLASSIC:
            this.gameController = new ClassicGameController(newGame, this);
            break;
        case LINETRIS:
            this.gameController = new LintrisGameController(newGame, this);
            break;
        case SPIDER_LINE:
            this.gameController = new SpiderLineFourGameController(newGame, this);
            break;
        default:
            break;
        }
        
        
        showScene(this.gameController.gameView);
    }

    private boolean isValidPlayerName(String namePlayer, String nameComputer) {
        if (namePlayer.equalsIgnoreCase(nameComputer)) {
            return false;
        }
        return true;
    }

    public void onGameEnded() {
        loadHighscoreList();
        showScene(this.gameMenuView);
    }

    private void showScene(Parent view) {
        Scene scene = this.stage.getScene();
        scene.setRoot(view);
        this.stage.sizeToScene();
    }
}
