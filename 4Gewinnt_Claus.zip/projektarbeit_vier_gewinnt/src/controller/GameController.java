package controller;

import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.ToIntFunction;

import db.DBException;
import db.DBOperations;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.shape.Shape;
import main.Difficulty;
import main.GameVariant;
import model.Board;
import model.Computer;
import model.Coordinate;
import model.Game;
import model.Player;
import view.GameView;

public abstract class GameController {
    private List<Game> games;
    protected GameView gameView;
    protected Game gameModel;
    protected Board board;
    protected SimpleObjectProperty<Player> activePlayer = new SimpleObjectProperty<>();
    protected GameVariant gameVariant;
    protected GameMenuController gameMenuController;
    private LocalTime moveStartTime;
    protected SimpleIntegerProperty moves = new SimpleIntegerProperty(0);
    private Thread moveTimeTimerThread;
    private Thread gameDurationTimerThread;
    private Duration duration;
    protected Duration moveDuration;
    
    public GameController(Game newGame, GameMenuController gameMenuController) {
	this.setGameModel(newGame);
	this.setGameMenuController(gameMenuController);
	this.setGameVariant(this.gameModel.getGAME_VARIANT());
	this.setGameView(new GameView(this.gameVariant));
	this.checkPlayerMode();
	this.setBoard(new Board());
	this.initViewEvents();
	this.calculateMove(this.gameModel.getDIFFICULTY());
	this.startGame();
	this.finishMove();
    }
    
    public void setGameModel(Game game) {
	this.gameModel = game;
    }
    
    public void setGameView(GameView gameView) {
	this.gameView = new GameView(this.gameVariant);
    }
    
    public void setBoard(Board board) {
	this.board = board;
    }
    
    public void setActivePlayer(Player activePlayer) {
	this.activePlayer.set(activePlayer);
    }
    
    public void setGameVariant(GameVariant gameVariant) {
	this.gameVariant = gameVariant;
    }
    
    public void setGameMenuController(GameMenuController gameMenuController) {
	this.gameMenuController = gameMenuController;
    }
    
    public GameView getGameView() {
	return this.gameView;
    }
    
    private void startGame() {
	this.showActivePlayer();
    }
    
    protected void exitGame() {
	this.gameMenuController.onGameEnded();
    }
    
    private Player selectStartingPlayer() {
	Random random = new Random();
	int randomNumber = random.nextInt(10 + 1) + 1;
	if(randomNumber % 2 == 0) {
	    return this.gameModel.getPLAYER_ONE();
	} else {
	    return this.gameModel.getPLAYER_TWO();
	}
    }
    
    protected void finishMove() {
	this.gameView.getBoardView().setOnMouseClicked(new EventHandler<MouseEvent>() {
	    @Override
	    public void handle(MouseEvent event) {
		int column = gameView.getColumnIndex(event.getPickResult().getIntersectedNode());
		int row = gameView.getRowIndex(event.getPickResult().getIntersectedNode());
		try {
		    Shape circle = (Shape) event.getPickResult().getIntersectedNode();
		    if(gameView.getStartExitButton().getText() == "Start Game") {
			Alert errorStart = new Alert(AlertType.ERROR, "The game has not started!");
			errorStart.showAndWait();
		    } else if(circle.getFill() == gameView.getPlayerOneColor() || circle.getFill() == gameView.getPlayerTwoColor()) {
			Alert error = new Alert(AlertType.ERROR, "The field is already occupied!");
			error.showAndWait();
		    }else if(activePlayer.get().equals(gameModel.getPLAYER_ONE())) {
			circle.setFill(gameView.getPlayerOneColor());
			board.setField(gameView.getBoardView().getRowIndex(circle) - 1, gameView.getBoardView().getColumnIndex(circle), board.getFieldPLAYER_ONE());
			changeActivePlayer();
		    }else if(activePlayer.get().equals(gameModel.getPLAYER_TWO())) {
			circle.setFill(gameView.getPlayerTwoColor());
			board.setField(gameView.getBoardView().getRowIndex(circle) - 1, gameView.getBoardView().getColumnIndex(circle), board.getFieldPLAYER_TWO());
			changeActivePlayer();
		    } else {
			
		    }
		} catch(ClassCastException e) {   
		}
	    }
	});
    }
    
    protected boolean playerHasWon() {
	if(this.checkVertical() || this.checkHorizontal() || this.checkDiagonalRight() || this.checkDiagonalLeft()) {
	    return true;
	}
	return false;
    }
    
    protected abstract void calculateMove(Difficulty difficulty);
    
    private void showActivePlayer() {
	this.activePlayer.addListener(new ChangeListener<Player>() {

	    @Override
	    public void changed(ObservableValue<? extends Player> observable, Player oldValue, Player newValue) {
		if(newValue.equals(gameModel.getPLAYER_ONE())) {
		    gameView.getInfoView().getPlayerOneBox().setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.LIGHTGREY, CornerRadii.EMPTY, Insets.EMPTY)));
		    gameView.getInfoView().getPlayerTwoBox().setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.WHITESMOKE, CornerRadii.EMPTY, Insets.EMPTY)));
		}
		if(newValue.equals(gameModel.getPLAYER_TWO())) {
		    gameView.getInfoView().getPlayerTwoBox().setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.LIGHTGREY, CornerRadii.EMPTY, Insets.EMPTY)));
		    gameView.getInfoView().getPlayerOneBox().setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.WHITESMOKE, CornerRadii.EMPTY, Insets.EMPTY)));
		}
	    }
	});
    }
    
    private void checkPlayerMode() {
	if(this.gameModel.getPLAYER_TWO().getClass().equals(Computer.class)) {
	    this.getGameView().getInfoView().setPVCMode();
	    this.getGameView().getInfoView().getPlayerOneBox().setName(this.gameModel.getPLAYER_ONE().getName());
	}else {
	    this.getGameView().getInfoView().setPVPMode();
	    this.getGameView().getInfoView().getPlayerOneBox().setName(this.gameModel.getPLAYER_ONE().getName());
	    this.getGameView().getInfoView().getPlayerTwoBox().setName(this.gameModel.getPLAYER_TWO().getName());
	}
    }
    
    private void initViewEvents() {
	this.gameView.getStartExitButton().setOnAction(new EventHandler<ActionEvent>() {
	@Override
		public void handle(ActionEvent event) {
		    if (gameView.getStartExitButton().getText() == "Start Game") {
			gameModel.setGameStart();
			setGameDuration();
			setMoveTime();
			gameView.getStartExitButton().setText("Exit Game");
			if (selectStartingPlayer() == gameModel.getPLAYER_ONE()) {
			    setActivePlayer(gameModel.getPLAYER_ONE());
			}else {
			    setActivePlayer(gameModel.getPLAYER_TWO());
			}
		    }else if(gameView.getStartExitButton().getText() == "Exit Game") {
			Alert exitAlert = new Alert(AlertType.CONFIRMATION, "You will exit the Game! Are you sure?", ButtonType.YES, ButtonType.CANCEL);
			exitAlert.showAndWait();
			if(exitAlert.getResult() == ButtonType.YES) {
			    gameMenuController.onGameEnded();
			}
		    }
		}
	});
	this.gameView.getInfoView().getTotalMovesLabel().textProperty().bind(this.moves.asString());
    }
    
    protected void changeActivePlayer() {
	if (playerHasWon() == true) {
	    this.gameModel.setScore(Math.toIntExact(this.duration.getSeconds()) * Math.round(this.moves.get() / 2));
	    this.activePlayer.getValue().setWinner(true);
	    try {
		DBOperations.insertGame(this.gameModel);
		this.moveTimeTimerThread.stop();
		this.gameDurationTimerThread.stop();
		Alert winAlert = new Alert(AlertType.INFORMATION, "Congratulations " + this.activePlayer.getValue().getName() + " you�re the winner!!!");
		winAlert.showAndWait();
	    } catch (DBException e) {
		Alert cantSave = new Alert(AlertType.ERROR, "Data set could not be saved!");
		cantSave.showAndWait();
	    }
	    this.exitGame();
	} else {
	    this.moveStartTime = LocalTime.now();
	    if (this.activePlayer.get() == gameModel.getPLAYER_ONE()) {
		this.activePlayer.set(gameModel.getPLAYER_TWO());
	    } else if (this.activePlayer.get() == gameModel.getPLAYER_TWO()) {
		this.activePlayer.set(gameModel.getPLAYER_ONE());
	    }
	}
	this.moves.set(this.moves.get() + 1);
	if(this.moves.get() == 42) {
	    Alert draw = new Alert(AlertType.INFORMATION, "Draw! No one has won...");
	    draw.showAndWait();
	    this.exitGame();
	}
    }
    
    private void setGameDuration() {
	this.gameDurationTimerThread = new Thread(() -> {
	        while (true) {
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	            this.duration = Duration.between(this.gameModel.getGameStart(), LocalTime.now());
	            final String time = LocalTime.MIDNIGHT.plus(duration).format(DateTimeFormatter.ofPattern("HH:mm:ss"));
	            Platform.runLater(() -> {
	        	this.gameView.getInfoView().getGameDurationLabel().setText(time);
	            });
	        }
	    }); 
	gameDurationTimerThread.start();
    }
    
    private void setMoveTime() {
	this.moveStartTime = LocalTime.now();
	this.moveTimeTimerThread = new Thread(() -> {
	        while (true) {
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	            this.moveDuration = Duration.between(this.moveStartTime, LocalTime.now());
	            final String time = "Move Duration: " + LocalTime.MIDNIGHT.plus(moveDuration).format(DateTimeFormatter.ofPattern("HH:mm:ss"));
	            Platform.runLater(() -> {
	        	if(this.activePlayer.get() == this.gameModel.getPLAYER_ONE()) {
	        	    this.gameView.getInfoView().getPlayerOneBox().getMoveTimeLabel().setText(time);
	        	    this.gameView.getInfoView().getPlayerTwoBox().getMoveTimeLabel().setText("Move Duration: ");
	        	} else if(this.activePlayer.get() == this.gameModel.getPLAYER_TWO()) {
	        	    this.gameView.getInfoView().getPlayerTwoBox().getMoveTimeLabel().setText(time);
	        	    this.gameView.getInfoView().getPlayerOneBox().getMoveTimeLabel().setText("Move Duration: ");
	        	}
	        	if(this.moveDuration.getSeconds() >= 30 && this.gameModel.getWithTimeLimit().get()) {
	        	    this.reachTimeLimit();
	        	}
	            });
	        }
	    }); 	
	this.moveTimeTimerThread.start();
    }
    
    
    private boolean checkVertical() {
	int player1 = 0;
	int player2 = 0;
	for(int i = 0; i < 7; i++) {
	    for(int j = 5; j >= 0; j--) {
		if(this.board.getBoard().get(j).get(i) == this.board.getFieldNONE()) {
		    player1 = 0;
		    player2 = 0;
		    break;
		} else if(this.board.getBoard().get(j).get(i) == this.board.getFieldPLAYER_ONE()) {
		    player1 += 1;
		    player2 = 0;
		} else if(this.board.getBoard().get(j).get(i) == this.board.getFieldPLAYER_TWO()) {
		    player1 = 0;
		    player2 += 1;
		}
		if(player1 == 4 || player2 == 4) {
		    return true;
		}
	    }
	}
	return false;
    }
    
    private boolean checkHorizontal() {
	for(int i = 5; i >= 0; i--) {
		int player1 = 0;
		int player2 = 0;
	    for(int j = 0; j < 7; j++) {
		if(this.board.getBoard().get(i).get(j) == this.board.getFieldNONE()) {
		    player1 = 0;
		    player2 = 0;
		    continue;
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_ONE()) {
		    player1 += 1;
		    player2 = 0;
		    if(player1 <= 1 && j >= 5) {
			break;
		    }
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_TWO()) {
		    player1 = 0;
		    player2 += 1;
		    if(player2 <= 1 && j >= 5) {
			break;
		    }
		}
		if(player1 == 4 || player2 == 4) {
		    return true;
		}
	    }
	}
	return false;
    }
    
    private boolean checkDiagonalRight() {
	for(int i = 5; i >= 0; i--) {
		int player1 = 0;
		int player2 = 0;
	    for(int j = 0; j < 7; j++) {
		if(this.board.getBoard().get(i).get(j) == this.board.getFieldNONE()) {
		    player1 = 0;
		    player2 = 0;
		    continue;
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_ONE()) {
		    player1 += 1;
		    player2 = 0;
		    if(j < 4 && i > 2) {
        		    for (int k = 1; k < 4; k++) {
        			if (this.board.getBoard().get(i - k).get(j + k) == this.board.getFieldPLAYER_ONE()) {
        			    player1 += 1;
        			    player2 = 0;
        			} else {
        			    player1 = 0;
        			    player2 = 0;
        			    break;
        			}
        		    }
		    }
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_TWO()) {
		    player1 = 0;
		    player2 += 1;
		    if(j < 4 && i > 2) {
        		    for (int k = 1; k < 4; k++) {
        			if (this.board.getBoard().get(i - k).get(j + k) == this.board.getFieldPLAYER_TWO()) {
        			    player1 = 0;
        			    player2 += 1;
        			} else {
        			    player1 = 0;
        			    player2 = 0;
        			    break;
        			}
        		    }
		    }
		}
		if(player1 == 4 || player2 == 4) {
		    return true;
		}
	    }
	}
	return false;
    }
    
    private boolean checkDiagonalLeft() {
	for(int i = 5; i >= 0; i--) {
		int player1 = 0;
		int player2 = 0;
	    for(int j = 6; j >= 0; j--) {
		if(this.board.getBoard().get(i).get(j) == this.board.getFieldNONE()) {
		    player1 = 0;
		    player2 = 0;
		    continue;
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_ONE()) {
		    player1 += 1;
		    player2 = 0;
		    if(j > 2 && i > 2) {
        		    for (int k = 1; k < 4; k++) {
        			if (this.board.getBoard().get(i - k).get(j - k) == this.board.getFieldPLAYER_ONE()) {
        			    player1 += 1;
        			    player2 = 0;
        			} else {
        			    player1 = 0;
        			    player2 = 0;
        			    break;
        			}
        		    }
		    }
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_TWO()) {
		    player1 = 0;
		    player2 += 1;
		    if(j > 2 && i > 2) {
        		    for (int k = 1; k < 4; k++) {
        			if (this.board.getBoard().get(i - k).get(j - k) == this.board.getFieldPLAYER_TWO()) {
        			    player1 = 0;
        			    player2 += 1;
        			} else {
        			    player1 = 0;
        			    player2 = 0;
        			    break;
        			}
        		    }
		    }
		}
		if(player1 == 4 || player2 == 4) {
		    return true;
		}
	    }
	}
	return false;
    }
    
    protected abstract void reachTimeLimit();
}
