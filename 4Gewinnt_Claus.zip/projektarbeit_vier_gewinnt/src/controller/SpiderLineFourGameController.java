package controller;

import java.time.Duration;

import main.Difficulty;
import model.Game;

public class SpiderLineFourGameController extends GameController {

    public SpiderLineFourGameController(Game newGame, GameMenuController gameMenuController) {
	super(newGame, gameMenuController);
    }

    @Override
    protected void calculateMove(Difficulty difficulty) {
	// TODO Auto-generated method stub
	
    }

    @Override
    protected void reachTimeLimit() {
	// TODO Auto-generated method stub
	
    }
}
