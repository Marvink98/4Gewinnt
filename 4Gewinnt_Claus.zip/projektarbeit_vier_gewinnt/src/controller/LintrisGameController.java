package controller;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Shape;
import main.Difficulty;
import model.Board;
import model.Game;
import model.Player;
import view.GameView;

public class LintrisGameController extends GameController {
    
    private List<Integer> randomIntList = new ArrayList<>();

    public LintrisGameController(Game newGame, GameMenuController gameMenuController) {
	super(newGame, gameMenuController);
	for(int i = 0; i < 7; i++) {
		this.randomIntList.add(i);
	}
    }
    
    @Override
    protected void finishMove() {
	this.gameView.getBoardView().setOnMouseClicked(new EventHandler<MouseEvent>() {
	    @Override
	    public void handle(MouseEvent event) {
		int column = gameView.getColumnIndex(event.getPickResult().getIntersectedNode());
		int row = gameView.getRowIndex(event.getPickResult().getIntersectedNode());
		try {
		    Shape circle = (Shape) event.getPickResult().getIntersectedNode();
		    if(gameView.getStartExitButton().getText() == "Start Game") {
			Alert errorStart = new Alert(AlertType.ERROR, "Das Spiel hat noch nicht begonnen");
			errorStart.showAndWait();
		    } else if(circle.getFill() == gameView.getPlayerOneColor() || circle.getFill() == gameView.getPlayerTwoColor()) {
			Alert error = new Alert(AlertType.ERROR, "Das Feld ist schon belegt");
			error.showAndWait();
		    }else if(activePlayer.get().equals(gameModel.getPLAYER_ONE())) {
			moveDown(gameView.getBoardView().getColumnIndex(circle), activePlayer);
			changeActivePlayer();
			deleteLastLine();
		    }else if(activePlayer.get().equals(gameModel.getPLAYER_TWO())) {
			moveDown(gameView.getBoardView().getColumnIndex(circle), activePlayer);
			changeActivePlayer();
			deleteLastLine();
		    } else {
			
		    }
		} catch(ClassCastException e) {   
		}
	    }
	});
    }
    
    private void moveDown(int column, SimpleObjectProperty<Player> activePlayer) {
	for(int i = 0; i < 6; i++) {
	    if(this.board.getBoard().get(i).get(column) != this.board.getFieldNONE()) {
		if(activePlayer.getValue() == this.gameModel.getPLAYER_ONE()) {
		    this.board.setField(i - 1, column, this.board.getFieldPLAYER_ONE());
		    Shape node = (Shape) this.getNodeByRowColumnIndex(i, column, this.gameView.getBoardView());
		    node.setFill(this.gameView.getPlayerOneColor());
		    return;
		} else {
		    this.board.setField(i - 1, column, this.board.getFieldPLAYER_TWO());
		    Shape node = (Shape) this.getNodeByRowColumnIndex(i, column, this.gameView.getBoardView());
		    node.setFill(this.gameView.getPlayerTwoColor());
		    return;
		}
	    } else if(i == 5) {
		if(activePlayer.getValue() == this.gameModel.getPLAYER_ONE()) {
		    this.board.setField(i, column, this.board.getFieldPLAYER_ONE());
		    Shape node = (Shape) this.getNodeByRowColumnIndex(i + 1, column, this.gameView.getBoardView());
		    node.setFill(this.gameView.getPlayerOneColor());
		    return;
		} else {
		    this.board.setField(i, column, this.board.getFieldPLAYER_TWO());
		    Shape node = (Shape) this.getNodeByRowColumnIndex(i + 1, column, this.gameView.getBoardView());
		    node.setFill(this.gameView.getPlayerTwoColor());
		    return;
		}
	    } else {
		
	    }
	}
    }
    
    private Node getNodeByRowColumnIndex (final int row, final int column, GridPane gridPane) {
	    Node result = null;
	    ObservableList<Node> childrens = gridPane.getChildren();

	    for (Node node : childrens) {
	        if(gridPane.getRowIndex(node) == row && gridPane.getColumnIndex(node) == column) {
	            result = node;
	            break;
	        }
	    }

	    return result;
    }

    @Override
    protected void calculateMove(Difficulty difficulty) {
	    this.randomIntList = new ArrayList<>();
	    if (difficulty == Difficulty.EASY) {
		this.activePlayer.addListener(new ChangeListener<Player>() {
		    @Override
		    public void changed(ObservableValue<? extends Player> observable, Player oldValue,
			    Player newValue) {
			if (newValue.equals(gameModel.getPLAYER_TWO())) {
			    Random randomNumber = new Random();
			    int randomInt = randomIntList.get(randomNumber.nextInt((randomIntList.size() - 1) - 0 + 1) + 0);
			    try {
				moveDown(randomInt, activePlayer);
			    } catch(ArrayIndexOutOfBoundsException e) {
				randomIntList.remove(Integer.valueOf(randomInt));
				changed(observable, oldValue, newValue);
			    }
			    changeActivePlayer();
			}
		    }
		});
	    }
    }

    @Override
    protected void reachTimeLimit() {
	    Random randomNumber = new Random();
	    int randomInt = randomIntList.get(randomNumber.nextInt((randomIntList.size() - 1) - 0 + 1) + 0);
	    try {
		moveDown(randomInt, activePlayer);
	    } catch (ArrayIndexOutOfBoundsException e) {
		randomIntList.remove(Integer.valueOf(randomInt));
		reachTimeLimit();
	    }
	    changeActivePlayer();
    }
    
    private void deleteLastLine() {
	for(int i = 0; i < 7; i++) {
	    if(this.board.getBoard().get(5).get(i) == this.board.getFieldNONE()) {
		return;
	    } else {
		continue;
	    }
	}
	
	this.board.getBoard().remove(5);
	this.board.getBoard().add(0, new ArrayList<Board.Field>());
	for(int j = 0; j < 7; j++) {
	    this.board.getBoard().get(0).add(this.board.getFieldNONE());
	}
	updateBoardView();
    }
    
    private void updateBoardView() {
	for(int i = 0; i < 6; i++) {
	    for(int j = 0; j < 7; j++) {
		Shape circle = (Shape) this.getNodeByRowColumnIndex(i + 1, j, this.gameView.getBoardView());
		if(this.board.getBoard().get(i).get(j) == this.board.getFieldNONE()) {
		    circle.setFill(GameView.COLOR_NONE);
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_ONE()) {
		    circle.setFill(GameView.COLOR_PLAYER_ONE);
		} else if(this.board.getBoard().get(i).get(j) == this.board.getFieldPLAYER_TWO()) {
		    circle.setFill(GameView.COLOR_PLAYER_TWO);
		}
	    }
	}
    }
}
