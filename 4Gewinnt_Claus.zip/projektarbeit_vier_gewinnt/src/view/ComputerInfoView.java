package view;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;

public class ComputerInfoView extends PlayerInfoView {
    
    public ComputerInfoView() {
	super();
	this.setIcon(FontAwesomeIcon.DESKTOP);
	this.setName("Computer");
    }
    
    
}
