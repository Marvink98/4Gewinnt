package view;

import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TabPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import main.GameVariant;

public class ConfigGameView extends VBox {
    private ToggleGroup gameVariantGrp = new ToggleGroup();
    private RadioButton classicBtn = new RadioButton("Classic");
    private RadioButton linetrisBtn = new RadioButton("Linetris");
    private RadioButton spiderLineFourBtn = new RadioButton("Spider Line Four");
    private CheckBox timeLimitCbx = new CheckBox("With Time limit (30s)");
    private PVPView pvpView = new PVPView();
    private PVCView pvcView = new PVCView();
    private TabPane modeTabPane = new TabPane(this.pvcView, this.pvpView);
    private Button startGameBtn = new Button("Start Game");
    
    public ConfigGameView() {
        createView();
        styleView();
    }
    
    private void createView() {
        this.classicBtn.setToggleGroup(gameVariantGrp);
        this.linetrisBtn.setToggleGroup(gameVariantGrp);
        this.spiderLineFourBtn.setToggleGroup(gameVariantGrp);
        this.gameVariantGrp.selectToggle(classicBtn);
        
        getChildren().addAll(new HBox(Layouts.H_GAP, this.classicBtn, this.linetrisBtn, this.spiderLineFourBtn),
                this.timeLimitCbx,
                this.modeTabPane,
                this.startGameBtn);
        
        this.classicBtn.setUserData(GameVariant.CLASSIC);
        this.linetrisBtn.setUserData(GameVariant.LINETRIS);
        this.spiderLineFourBtn.setUserData(GameVariant.SPIDER_LINE);
    }
    
    private void styleView() {
        setSpacing(Layouts.V_GAP);
        this.startGameBtn.minWidthProperty().bind(this.widthProperty());
        this.modeTabPane.getStyleClass().add("floating");
    }

    public ToggleGroup getGameVariantGrp() {
        return gameVariantGrp;
    }

    public CheckBox getTimeLimitCbx() {
        return timeLimitCbx;
    }

    public PVPView getPvpView() {
        return pvpView;
    }

    public PVCView getPvcView() {
        return pvcView;
    }

    public TabPane getModeTabPane() {
        return modeTabPane;
    }

    public Button getStartGameBtn() {
        return startGameBtn;
    }

    public RadioButton getClassicBtn() {
        return classicBtn;
    }
    
    
    
}
