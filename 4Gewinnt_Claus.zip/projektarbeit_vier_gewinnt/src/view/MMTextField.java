package view;

import javafx.scene.control.TextField;

public class MMTextField extends TextField {
    
    public MMTextField() {
    }
    
    public void promptError() {
        String oldStyle = this.getStyle();
        String oldPromptText = this.getPromptText();
        this.setStyle("-fx-background-color: #ffabab; -fx-prompt-text-fill: #d64e4e;");
        this.setPromptText("Enter name");
    }
    
}
