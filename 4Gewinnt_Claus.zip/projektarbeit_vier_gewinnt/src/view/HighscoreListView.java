package view;

import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import model.Game;

public class HighscoreListView extends ListView<Game> {

    private Label placeholderLbl = new Label("No games available");

    public HighscoreListView() {
        styleView();
        this.setCellFactory(list -> new HighscoreListCell());
    }

    private void styleView() {
        this.setMinWidth(220);
        this.setMaxWidth(220);

        this.setEditable(false);
        this.setPlaceholder(placeholderLbl);

    }

    public Label getPlaceholderLbl() {
        return placeholderLbl;
    }

}
