package view;

import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;

public class PVPView extends Tab {
    private TextField namePlayerOneTxF = new TextField();
    private TextField namePlayerTwoTxF = new TextField();

    public PVPView() {
        createView();
    }

    private void createView() {

        this.setText("Player vs Player");
        this.setClosable(false);
        this.namePlayerOneTxF.setPromptText("Name Player One");
        this.namePlayerTwoTxF.setPromptText("Name Player Two");
        HBox pane = new HBox(Layouts.H_GAP, this.namePlayerOneTxF, this.namePlayerTwoTxF);
        pane.setPadding(Layouts.FRAME_INSETS);
        
        this.setContent(pane);
        
    }

    public TextField getNamePlayerOneTxF() {
        return namePlayerOneTxF;
    }

    public TextField getNamePlayerTwoTxF() {
        return namePlayerTwoTxF;
    }
    
    
}
