package view;

import javafx.geometry.Insets;

public class Layouts {
    public static final double V_GAP = 7;
    public static final double H_GAP = 10;
    public static final double WINDOW_H_SIZE = 500;
    public static final double WINDOW_V_SIZE = 400;
    public static final Insets FRAME_INSETS = new Insets(10,10,10,10);
    
    private Layouts() {
        
    }
}
