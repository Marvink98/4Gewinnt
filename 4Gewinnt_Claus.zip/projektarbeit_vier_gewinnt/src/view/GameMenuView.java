package view;

import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class GameMenuView extends GridPane {

    private Label h1 = new Label("Connect 4");
    private Label h2 = new Label("Make your move!");
    private HighscoreListView highscoreView = new HighscoreListView();
    private ConfigGameView configView = new ConfigGameView();

    public GameMenuView() {
        createView();
        styleView();
    }

    private void createView() {
        add(this.h1, 0, 0, 2, 1);
        add(this.h2, 0, 1, 2, 1);
        add(new VBox(Layouts.V_GAP,new Label("Leaderboard"), this.highscoreView), 0, 2);
        add(this.configView, 1, 2);
    }
    
    private void styleView() {
        this.setPadding(Layouts.FRAME_INSETS);
        
        GameMenuView.setHalignment(this.h1, HPos.CENTER);
        GameMenuView.setHalignment(this.h2, HPos.CENTER);
        this.setHgap(Layouts.H_GAP);
        
        this.h1.setStyle("-fx-font-weight: bold; -fx-font-size: 24; -fx-padding: 10 0 0 0");
        this.h2.setStyle("-fx-font-size: 14; -fx-padding: 0 0 20 0");
    }

    public HighscoreListView getHighscoreView() {
        return highscoreView;
    }

    public ConfigGameView getConfigView() {
        return configView;
    }
    
    
}
