package view;

import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import main.GameVariant;

public class ManualView extends VBox {
    private Label modeLabel = new Label();
    private Label manualLabel = new Label();

    private String classicManual = "Das Spiel wird auf einem senkrecht stehenden hohlen Spielbrett gespielt, "
    	+ "in das die Spieler abwechselnd ihre Spielsteine fallen lassen. "
    	+ "Das Spielbrett besteht aus sieben Spalten (senkrecht) und sechs Reihen (waagerecht). "
    	+ "Jeder Spieler besitzt 21 gleichfarbige Spielsteine. Wenn ein Spieler einen Spielstein in eine Spalte fallen l�sst, "
    	+ "besetzt dieser den untersten freien Platz der Spalte. Gewinner ist der Spieler, der es als erster schafft, "
    	+ "vier oder mehr seiner Spielsteine waagerecht, senkrecht oder diagonal in eine Linie zu bringen. "
    	+ "Das Spiel endet unentschieden, wenn das Spielbrett komplett gef�llt ist, ohne dass ein Spieler eine Viererlinie gebildet hat.";
    
    private String linetrisManual = "";
    private String spiderLineManual = "";

    public ManualView(GameVariant gameVariant) {
	this.createManualView(gameVariant);
    }
    
    private void createManualView(GameVariant gameVariant) {
        ScrollPane scrollPane = new ScrollPane(manualLabel);
        scrollPane.setMinHeight(150);
        scrollPane.setMinWidth(250);
        scrollPane.setMaxWidth(250);
        this.modeLabel.setStyle("-fx-font-weight: bold;");
        this.manualLabel.setWrapText(true);
        this.manualLabel.maxWidthProperty().bind(scrollPane.widthProperty().subtract(15));;
	checkGameVariant(gameVariant);
	this.getChildren().add(modeLabel);
	this.getChildren().add(scrollPane);
    }
    
    private void checkGameVariant(GameVariant gameVariant) {
	if(gameVariant == GameVariant.CLASSIC) {
	    this.modeLabel.setText("Klassisch");
	    this.manualLabel.setText(classicManual);
	} else if(gameVariant == GameVariant.LINETRIS) {
	    this.modeLabel.setText("Linetris");
	    this.manualLabel.setText(linetrisManual);
	} else if(gameVariant == GameVariant.SPIDER_LINE) {
	    this.modeLabel.setText("Spider Line Four");
	    this.manualLabel.setText(spiderLineManual);
	}
    }
}
