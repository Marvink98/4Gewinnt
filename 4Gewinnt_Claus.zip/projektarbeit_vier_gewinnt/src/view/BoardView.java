package view;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

public class BoardView extends GridPane {
    public BoardView() {
	this.createNormalBoardView(this);
    }

    private void createNormalBoardView(GridPane board) {
	board.setVgap(2);
	board.setHgap(2);
	for (int i = 0; i < 7; i++) {
	    for (int j = 0; j < 7; j++) {
		if (i == 0) {
		    board.add(new Rectangle(40, 40, Color.WHITESMOKE), j, i);
		} else {
		    Shape newCircle = new Circle(20, Color.LIGHTGRAY);
		    newCircle.setOnMouseMoved(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
			    FontAwesomeIconView arrow = new FontAwesomeIconView(FontAwesomeIcon.ANGLE_DOWN);
			    arrow.setSize("40");
			    board.add(arrow, board.getColumnIndex(newCircle), 0);
			    GridPane.setHalignment(arrow, HPos.CENTER);
			    if(newCircle.getFill() == GameView.COLOR_PLAYER_ONE || newCircle.getFill() == GameView.COLOR_PLAYER_TWO) {
				
			    } else {
			        newCircle.setFill(Color.GREY);
			    }
			}
		    });
		    newCircle.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
			    board.add(new Rectangle(40, 40, Color.WHITESMOKE), board.getColumnIndex(newCircle), 0);
			    if(newCircle.getFill() == GameView.COLOR_PLAYER_ONE || newCircle.getFill() == GameView.COLOR_PLAYER_TWO) {
				
			    } else {
				newCircle.setFill(Color.LIGHTGRAY);
			    }
			}
		    });
		    board.add(newCircle, j, i);
		}
	    }
	}
    }
}
