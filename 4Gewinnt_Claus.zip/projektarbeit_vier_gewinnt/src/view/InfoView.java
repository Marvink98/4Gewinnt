package view;

import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class InfoView extends VBox {
    private Label gameDurationLabel = new Label();
    private Label totalMovesLabel = new Label();
    private PlayerInfoView playerOneBox;
    private PlayerInfoView playerTwoBox;

    public InfoView() {
        this.createInfoView();
    }

    private void createInfoView() {
        this.getChildren().add(new HBox(new Label("Game duration: "),gameDurationLabel));
        this.getChildren().add(new HBox(new Label("Total moves: "),totalMovesLabel));
        
        
//	this.getChildren().add(playerOneBox);
//	this.getChildren().add(playerTwoBox);
    }

    private void styleIcons() {
        this.playerOneBox.getIcon().setFill(GameView.COLOR_PLAYER_ONE);
        this.playerTwoBox.getIcon().setFill(GameView.COLOR_PLAYER_TWO);
    }

    public PlayerInfoView getPlayerOneBox() {
        return this.playerOneBox;
    }

    public PlayerInfoView getPlayerTwoBox() {
        return this.playerTwoBox;
    }

    public void setPVCMode() {
        this.playerOneBox = new PlayerInfoView();
        this.playerTwoBox = new ComputerInfoView();
        this.getChildren().add(playerOneBox);
        this.getChildren().add(playerTwoBox);
        styleIcons();
    }

    public void setPVPMode() {
        this.playerOneBox = new PlayerInfoView();
        this.playerTwoBox = new PlayerInfoView();
        this.getChildren().add(playerOneBox);
        this.getChildren().add(playerTwoBox);
        styleIcons();
    }

    public Label getGameDurationLabel() {
        return this.gameDurationLabel;
    }

    public Label getTotalMovesLabel() {
        return this.totalMovesLabel;
    }
}
