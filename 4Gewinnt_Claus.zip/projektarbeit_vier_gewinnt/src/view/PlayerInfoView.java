package view;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class PlayerInfoView extends GridPane{
    private Label nameLabel = new Label();
    private Label moveTimeLabel = new Label();
    private FontAwesomeIconView icon = new FontAwesomeIconView(FontAwesomeIcon.USER);
    
    public PlayerInfoView() {
	this.createPlayerInfoView();
	styleView();
    }
    
    private void styleView() {
        this.setPadding(Layouts.FRAME_INSETS);    
        this.setHgap(Layouts.H_GAP);
        
    }

    protected void setIcon(FontAwesomeIcon icon) {
	this.icon.setIcon(icon);
    }
    
    public void setName(String name) {
	this.nameLabel.setText(name);
    }
    
    private void createPlayerInfoView() {
	this.add(this.icon, 0, 0);
	this.add(this.nameLabel, 1, 0);
	this.add(this.moveTimeLabel, 1, 1);
    }
    
    public Label getMoveTimeLabel() {
	return this.moveTimeLabel;
    }

    public FontAwesomeIconView getIcon() {
        return icon;
    }
    
    
}
