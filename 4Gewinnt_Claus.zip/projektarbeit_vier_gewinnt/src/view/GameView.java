package view;

import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import main.GameVariant;

public class GameView extends GridPane {

    public static final Color COLOR_NONE = Color.LIGHTGRAY;
    public static final Color COLOR_PLAYER_ONE = Color.RED;
    public static final Color COLOR_PLAYER_TWO = Color.YELLOW;
    private BoardView board = new BoardView();
    private InfoView infoView = new InfoView();
    private ManualView manualView;
    private Button startExitButton = new Button("Start Game");

    public GameView(GameVariant gameVariant) {
        this.createGameView(gameVariant);
    }

    private void createGameView(GameVariant gameVariant) {
        checkGameType(gameVariant);
        this.add(this.board, 0, 0, 1, 3);
        this.add(this.infoView, 1, 0);
        this.add(this.manualView, 1, 1);
        this.add(this.startExitButton, 1, 2);
        
//        this.getChildren().stream().forEach(cell -> {
//            cell.setStyle("-fx-background-color: blue;");
//        });
//        
//        this.setStyle("-fx-background-color: red;");

        styleView();
    }

    private void styleView() {
        this.setPadding(Layouts.FRAME_INSETS);
        this.setHgap(Layouts.H_GAP);
        this.setVgap(Layouts.V_GAP);
        this.startExitButton.minWidthProperty().bind(this.manualView.widthProperty());
        
        
    }

    private void checkGameType(GameVariant gameVariant) {

        if (gameVariant == GameVariant.CLASSIC) {
            this.manualView = new ManualView(gameVariant);
        } else if (gameVariant == GameVariant.LINETRIS) {
            this.manualView = new ManualView(gameVariant);
        } else if (gameVariant == GameVariant.SPIDER_LINE) {
            this.manualView = new ManualView(gameVariant);
        }
    }

    public Button getStartExitButton() {
        return this.startExitButton;
    }

    public InfoView getInfoView() {
        return this.infoView;
    }

    public Color getPlayerOneColor() {
        return this.COLOR_PLAYER_ONE;
    }

    public Color getPlayerTwoColor() {
        return this.COLOR_PLAYER_TWO;
    }

    public BoardView getBoardView() {
        return this.board;
    }
}