package view;

import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import main.Difficulty;

public class PVCView extends Tab {
    private TextField namePlayerOneTxF = new TextField();
    private RadioButton easyBtn = new RadioButton("Roocky");
    private RadioButton mediumBtn = new RadioButton("Medium");
    private RadioButton hardBtn = new RadioButton("Advanced");
    private ToggleGroup difficultyGrp = new ToggleGroup();

    public PVCView() {
        createView();
    }

    private void createView() {

        this.setText("Player vs Computer");
        this.setClosable(false);
        this.namePlayerOneTxF.setPromptText("Enter your name");
        
        this.easyBtn.setToggleGroup(this.difficultyGrp);
        this.mediumBtn.setToggleGroup(this.difficultyGrp);
        this.hardBtn.setToggleGroup(this.difficultyGrp);
        this.difficultyGrp.selectToggle(easyBtn);
        VBox pane = new VBox(Layouts.V_GAP, this.namePlayerOneTxF,
                new HBox(Layouts.H_GAP, this.easyBtn, this.mediumBtn, this.hardBtn));
        pane.setPadding(Layouts.FRAME_INSETS);

        this.setContent(pane);
        
        this.easyBtn.setUserData(Difficulty.EASY);
        this.mediumBtn.setUserData(Difficulty.MEDIUM);
        this.hardBtn.setUserData(Difficulty.EXPERT);
    }

    public TextField getNamePlayerOneTxF() {
        return namePlayerOneTxF;
    }

    public ToggleGroup getDifficultyGrp() {
        return difficultyGrp;
    }
    
    
}
