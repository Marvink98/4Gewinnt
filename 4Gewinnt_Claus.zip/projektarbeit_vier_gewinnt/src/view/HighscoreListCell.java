package view;

import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.layout.VBox;
import model.Game;

public class HighscoreListCell extends ListCell<Game> {
    @Override
    protected void updateItem(Game game, boolean empty) {
        super.updateItem(game, empty);

        if (empty) {
            this.setText(null);
            this.setGraphic(null);
        } else {
            this.setText(null);
            Label firstRow = new Label(
                    String.format("%d - %s", game.getScore().getValue(), game.getWinner().getName()));
            Label secondRow = new Label(
                    String.format("%s vs %s", game.getPLAYER_ONE().getName(), game.getPLAYER_TWO().getName()));
            firstRow.setStyle("-fx-font-weight: bold;");
            this.setGraphic(new VBox(firstRow, secondRow));
        }
    }
}
