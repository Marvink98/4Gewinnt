package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static Connection connection = null;

    private DBConnection() {

    }

    public static Connection getConnection() throws DBException {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName("org.h2.Driver"); // Can be omitted in this version
                connection = DriverManager.getConnection("jdbc:h2:~/4Connect/highscoreDB", "admin", "secret");
            }
        } catch (ClassNotFoundException e) {
            throw new DBException("h2 Driver cannot be loaded.\n" + e.getMessage());
        } catch (SQLException e) {
            throw new DBException("Cannot establish DB Connection\n" + e.getMessage());
        }

        return connection;
    }

    public static void close() throws DBException {
        try {
            if (connection != null || !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            throw new DBException("DB cannot be closed.\n" + e.getMessage());
        }
    }

}
