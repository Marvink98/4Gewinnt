package db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import main.Difficulty;
import main.GameVariant;
import model.Computer;
import model.Game;
import model.Player;

public class DBOperations {
    
    private DBOperations() {
        
    }
    
    public static void createTable() throws DBException {
        String sql = "CREATE TABLE IF NOT EXISTS Highscore " +
                "(difficulty ENUM('NONE', 'EASY', 'MEDIUM', 'EXPERT'), " +
                "gameVariant ENUM('CLASSIC', 'LINETRIS', 'SPIDER_LINE'), " +
                "withTimeLimit BOOLEAN, " +
                "score INT , " +
                "nameWinner VARCHAR(50), " +
                "nameLooser VARCHAR(50));";
        try {
            Statement stmt = DBConnection.getConnection().createStatement();
            stmt.execute(sql);
            DBConnection.close();
        } catch (SQLException e) {
            throw new DBException("Create Table statement not correct\n" + e.getMessage());
        }
    }
    
    public static void insertGame(Game game) throws DBException, IllegalArgumentException {
        
        if (game.getPLAYER_ONE().isWinner() == game.getPLAYER_TWO().isWinner()) {
            throw new IllegalArgumentException("isWinner instance variable error on Player class. both values are equal");
        }
        
        String nameWinner = game.getPLAYER_ONE().isWinner() ? game.getPLAYER_ONE().getName() : game.getPLAYER_TWO().getName();
        String nameLooser = !game.getPLAYER_ONE().isWinner() ? game.getPLAYER_ONE().getName() : game.getPLAYER_TWO().getName();
        
        String sql = String.format("INSERT INTO Highscore (difficulty, gameVariant, withTimeLimit, score, nameWinner, nameLooser) VALUES ('%s', '%s', %d, %d, '%s', '%s');",
                game.getDIFFICULTY().toString(),
                game.getGAME_VARIANT().toString(),
                (game.getWithTimeLimit().getValue() ? 1 : 0),
                game.getScore().getValue(),
                nameWinner,
                nameLooser);
        try {
            Statement stmt = DBConnection.getConnection().createStatement();
            stmt.execute(sql);
            DBConnection.close();
        } catch (SQLException e) {
            throw new DBException("INSERT INTO statement for a new game is not correct\n" + e.getMessage());
        }
    }
    
    public static ObservableList<Game> getFilteredGamesList() throws DBException {
        ObservableList<Game> games = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM Highscore ORDER BY score ASC;";
        
        try {
            Statement stmt = DBConnection.getConnection().createStatement();
            ResultSet result = stmt.executeQuery(sql);
            
            while (result.next()) {
                Difficulty difficulty = Difficulty.valueOf(result.getString("difficulty"));
                GameVariant gameVariant = GameVariant.valueOf(result.getString("gameVariant"));
                boolean withTimeLimit = result.getBoolean("withTimeLimit");
                int score = result.getInt("score");
                Player winner = reconstructPlayerObj(result.getString("nameWinner"));
                winner.setWinner(true);
                Player looser = reconstructPlayerObj(result.getString("nameLooser"));
                Game game = new Game(difficulty, gameVariant, withTimeLimit, winner, looser);
                game.setScore(score);
                
                games.add(game);
            }
            
            DBConnection.close();
        } catch (SQLException e) {
            throw new DBException("SELECT * statement is not correct\n" + e.getMessage());
        }
        
        
        
        return games;
    }

    private static Player reconstructPlayerObj(String name) {
        if (name.equalsIgnoreCase("computer")) {
            return new Computer();
        }
        
        return new Player(name);
    }
}
