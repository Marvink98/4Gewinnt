package model;

public class Player {
    private String name;
    private boolean isWinner = false;
    
    public Player(String name) {
        this.name = name;
    }
    
    public String getName() {
	return this.name;
    }

    public boolean isWinner() {
        return isWinner;
    }

    public void setWinner(boolean isWinner) {
        this.isWinner = isWinner;
    }
    
    
}
