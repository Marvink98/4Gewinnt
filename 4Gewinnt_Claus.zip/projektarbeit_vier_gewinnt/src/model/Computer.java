package model;

public class Computer extends Player {

    public Computer() {
        super("Computer");
    }

}
