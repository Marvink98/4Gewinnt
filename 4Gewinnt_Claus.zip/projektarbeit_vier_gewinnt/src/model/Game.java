package model;

import java.time.LocalTime;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import main.Difficulty;
import main.GameVariant;

public class Game {
    private Difficulty difficulty;
    private GameVariant gameVariant;
    private BooleanProperty withTimeLimit = new SimpleBooleanProperty();
    private IntegerProperty score = new SimpleIntegerProperty(0);
    private Player playerOne;
    private Player playerTwo;
    private LocalTime GAME_START;

    public Game(Difficulty difficulty, GameVariant gameVariant, boolean withTimeLimit, Player playerOne,
            Player playerTwo) {
        this.difficulty = difficulty;
        this.gameVariant = gameVariant;
        this.withTimeLimit.setValue(withTimeLimit);
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
    }

    public Difficulty getDIFFICULTY() {
        return difficulty;
    }

    public GameVariant getGAME_VARIANT() {
        return gameVariant;
    }

    public IntegerProperty getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score.set(score);
    }

    public Player getPLAYER_ONE() {
        return playerOne;
    }

    public Player getPLAYER_TWO() {
        return playerTwo;
    }

    public LocalTime getGameStart() {
        return this.GAME_START;
    }

    public void setGameStart() {
        this.GAME_START = LocalTime.now();
    }

    public BooleanProperty getWithTimeLimit() {
        return withTimeLimit;
    }
    
    public Player getWinner() {
        if (this.playerOne.isWinner()) {
            return this.playerOne;
        } else if (this.playerTwo.isWinner()) {
            return this.playerTwo;
        } else {
            throw new IllegalArgumentException("winner is not correct set.");
        }
    }
    
    public Player getLooser() {
        if (!this.playerOne.isWinner()) {
            return this.playerOne;
        } else if (!this.playerTwo.isWinner()) {
            return this.playerTwo;
        } else {
            throw new IllegalArgumentException("looser is not correct set.");
        }
    }

    @Override
    public String toString() {
        return String.format("Winner %s (%d) vs %s - %s, %s",
                (this.playerOne.isWinner() ? this.playerOne.getName() : this.playerTwo.getName()),
                this.score.getValue(),
                (!this.playerOne.isWinner() ? this.playerOne.getName() : this.playerTwo.getName()),
                this.difficulty.toString(),
                this.gameVariant.toString());
    }

}
