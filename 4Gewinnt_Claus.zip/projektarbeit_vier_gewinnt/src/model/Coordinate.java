package model;

import model.Board.Field;

public class Coordinate {
    private int row;
    private int column;
    
    public Coordinate(int row, int column, Field field) {
	this.row = row;
	this.column = column;
    }
}
