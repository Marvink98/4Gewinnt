package model;

import java.util.ArrayList;
import java.util.List;

public class Board {
    private List<List<Field>> board = new ArrayList<>();
    public enum Field {NONE, PLAYER_ONE, PLAYER_TWO}
    
    public Board() {
	this.createBoard();
    }
    
    private void createBoard() {
	for(int i = 0; i < 6; i++) {
	    this.board.add(new ArrayList<Field>());
	    for(int j = 0; j < 7; j++) {
		this.board.get(i).add(j, Field.NONE);
	    }
	}
    }
    
    public List<List<Field>> getBoard() {
	return this.board;
    }
    
    public Field getFieldPLAYER_ONE() {
	return Field.PLAYER_ONE;
    }
    
    public Field getFieldPLAYER_TWO() {
	return Field.PLAYER_TWO;
    }
    
    public Field getFieldNONE() {
	return Field.NONE;
    }
    
    public void setField(int row, int column, Field field) {
	this.board.get(row).set(column, field);
	
//	for(int i = 0; i < 6; i++) {
//	    System.out.println("");
//	    for(int j = 0; j < 7; j++) {
//		System.out.print(this.board.get(i).get(j));
//	    }
//	}
    }
}
