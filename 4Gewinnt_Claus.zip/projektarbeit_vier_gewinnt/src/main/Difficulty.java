package main;

public enum Difficulty {
    NONE, EASY, MEDIUM, EXPERT;
}
