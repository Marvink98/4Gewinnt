package main;

import controller.GameMenuController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import view.GameMenuView;

public class StartGame extends Application {


    @Override
    public void start(Stage stage) {
        GameMenuView mainMenu = new GameMenuView();
        Scene scene = new Scene(mainMenu);
        new GameMenuController(mainMenu, stage);
        
        stage.setResizable(false);
        stage.setTitle("Connect 4 - by M&M");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
