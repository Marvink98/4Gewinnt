package main;

public enum GameVariant {
    CLASSIC, LINETRIS, SPIDER_LINE;
}
