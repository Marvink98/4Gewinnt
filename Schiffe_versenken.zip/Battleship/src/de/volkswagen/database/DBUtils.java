package de.volkswagen.database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import de.volkswagen.model.Player;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DBUtils {
    
    private static String INSERT_PLAYERS_WITH_HIGHSCORE = "INSERT INTO player VALUES(?, ?, ?);";
	
	private DBUtils() {
		
	}
	
	// Methode, die die Highscoretabelle anlegt, wenn sie noch nicht existiert
	public static void createHighscoreTable() {
		try (Statement createHighscoreTableStatement = DBConnection.getInstance().openConnection().createStatement()) {
			String createHighscoreTableSql = "CREATE TABLE IF NOT EXISTS player(NAME VARCHAR(50)"
					+ ", SCORE INTEGER, TURNS INTEGER);";
			createHighscoreTableStatement.execute(createHighscoreTableSql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
            DBConnection.getInstance().closeConnection();
        }
	}
	
	// Methode, die die Spieler mit ihrem Highscore in der Datenbank speichert
	public static void insertPlayerWithHighscore(Player player) {
	    try (PreparedStatement insertPlayers = DBConnection.getInstance().openConnection().prepareStatement(INSERT_PLAYERS_WITH_HIGHSCORE)) {
	        insertPlayers.setString(1, player.getName());
	        insertPlayers.setInt(2,  player.getScore());
	        insertPlayers.setInt(3,  player.getTurns());
	        insertPlayers.executeUpdate();
	    } catch (SQLException e) {
	        System.err.println("Spieler konnte nicht in die Datenbank �bertragen werden.");
	        e.printStackTrace();
	    } finally {
	        DBConnection.getInstance().closeConnection();
	    }  
	}

	//Methode, die alle gespeicherten Eintr�ge in der Datenbank abruft und sortiert nach dem Highscore in eine Liste speichert
	public static ObservableList<Player> getAllPlayers() {
	    ObservableList<Player> playerSelectedFromDatabase = FXCollections.observableArrayList();
	    
	    try (Statement selectFromDatabase = DBConnection.getInstance().openConnection().createStatement()) {
	        String getAllPlayerSql = "SELECT * FROM player ORDER BY SCORE DESC;";
	        ResultSet playerResult = selectFromDatabase.executeQuery(getAllPlayerSql);
	            while(playerResult.next()) {
	                playerSelectedFromDatabase.add(new Player(playerResult.getString("NAME"), playerResult.getInt("SCORE"), playerResult.getInt("TURNS")));
	            }
	     }catch (SQLException e) {
            System.err.println("Spieler konnten nicht aus der Datenbank geladen werden.");
            e.printStackTrace();
        } finally {
            DBConnection.getInstance().closeConnection();
        }  
		return playerSelectedFromDatabase;
	}

}
