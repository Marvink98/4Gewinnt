package de.volkswagen.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
    private static DBConnection instance;
    private Connection connection;
    
    private DBConnection() {
        
    }
    
    
    // Methode, die die Datenbankverbindung �ffnet, falls sie null oder geschlossen ist
    public Connection openConnection() {
        try {
            if (this.connection == null || this.connection.isClosed()) {
                this.connection = DriverManager.getConnection("jdbc:h2:~/battleship_project_db");
                System.out.println("Verbindung zur Datenbank wurde hergestellt");
            }
        } catch (SQLException ex) {
            System.err.println("Verbindung zur Datenbank konnte nicht aufgebaut werden!");
            ex.printStackTrace();
        }
        return this.connection;
    }
    
    //Methode, die die Datenbankverbindung schlie�t
    public void closeConnection() {
        try {
            if (this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
                System.out.println("Datenbankverbindung wurde geschlossen.");
            }
        } catch (SQLException ex) {
            System.err.println("Datenbankverbindung konnte nicht geschlossen werden!");
            ex.printStackTrace();
        }
    }
    
    // Methode, die eine eine neue DBConnection erstellt, falls es diese noch nicht gibt
    public static DBConnection getInstance() {
        if (instance == null) {
            instance = new DBConnection();
        }
        return instance;
    }

}
