package de.volkswagen.threads;

import de.volkswagen.view.PlaygroundView;
import javafx.application.Platform;

public class TotalTimeThread extends Thread{

	PlaygroundView playgroundView;
	int totalMinutes;
	int totalSeconds;
	int currentMinutes;
	int currentSeconds;
	
	public TotalTimeThread(PlaygroundView playgroundView) {
		setDaemon(true);
		this.playgroundView = playgroundView;
		this.totalMinutes = 0;
		this.totalSeconds = 0;
		this.currentMinutes = 0;
		this.currentSeconds = 0;
	}
	
	
	@Override
	public void run() {
		
		Platform.runLater(new Runnable(){
			
			@Override
			public void run() {
				while(true) {
				playgroundView.getCurrentPlayTimeLabel().setText(
						totalMinutes + ":" + totalSeconds);
				totalSeconds++;
				if(totalSeconds == 60) {
					totalMinutes++;
					totalSeconds = 0;
				}
				try {
					sleep(1000);
					System.out.println(totalMinutes + ":" + totalSeconds);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			
				}
			}
		});
	}
	
}
