package de.volkswagen.application;

import de.volkswagen.controller.StartViewController;
import de.volkswagen.database.DBUtils;
import de.volkswagen.view.StartView;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
	    DBUtils.createHighscoreTable();
		StartViewController startViewController = new StartViewController(new StartView());
		
		primaryStage.setScene(startViewController.start(primaryStage));
		primaryStage.sizeToScene();
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
	
}