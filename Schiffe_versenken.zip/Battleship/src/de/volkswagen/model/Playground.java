package de.volkswagen.model;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

public class Playground {
    
    private String[][] placementPlayer;
    private String[][] placementEnemy;
    private Player player;
    private Player enemy;
    
    public Playground(String[][] placementPlayer, Player player, String[][] placementEnemy,  Player enemy) {
        this.placementPlayer = placementPlayer;
        this.placementEnemy = placementEnemy;
        this.player = player;
        this.enemy = enemy;
    }

    public String[][] getPlacementPlayer() {
        return placementPlayer;
    }

    public String[][] getPlacementEnemy() {
        return placementEnemy;
    }

    public Player getPlayer() {
        return player;
    }

    public Player getEnemy() {
        return enemy;
    }

}
