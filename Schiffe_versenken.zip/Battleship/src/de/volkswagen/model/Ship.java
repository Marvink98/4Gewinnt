package de.volkswagen.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Ship {
    
    private IntegerProperty casket = new SimpleIntegerProperty();
    private IntegerProperty amount = new SimpleIntegerProperty();
    private StringProperty type = new SimpleStringProperty();
	
	public Ship(int amount, String type) {
		this.amount.set(amount);
		this.type.set(type);
	}
	
	
	public int getCasket() {
		return this.casket.get();
	}
	
	public int getAmount() {
		return this.amount.get();
	}

	public String getType() {
		return this.type.get();
	}

}
