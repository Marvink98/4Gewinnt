package de.volkswagen.model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Player {
    
    private StringProperty name = new SimpleStringProperty();
    private IntegerProperty score = new SimpleIntegerProperty();
    private BooleanProperty aI = new SimpleBooleanProperty();
    private IntegerProperty turns = new SimpleIntegerProperty();
	
	public Player(String name) {
		this.name.set(name);
		this.score.set(0);
		if (name.equals("Computer")) {
		    this.aI.set(true);
		} else {
		    this.aI.set(false);
		}
		this.turns.set(0);	
	}
	
	// Konstruktor f�r die HighscoreTableView
	public Player(String name, int score, int turns) {
	    this.name.set(name);
	    this.score.set(score);
	    this.turns.set(turns);
	}
	
	public String getName() {
		return this.name.get();
	}

	public int getScore() {
		return this.score.get();
	}
	
	public void setScore(int score) {
		this.score.set(score);
	}

	public boolean getAI() {
		return this.aI.get();
	}

	public int getTurns() {
		return this.turns.get();
	}


}
