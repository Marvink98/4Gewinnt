package de.volkswagen.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;

public class ShipPlacement {
    
    private IntegerProperty width = new SimpleIntegerProperty();
    private IntegerProperty height = new SimpleIntegerProperty();
    private ObjectProperty<Player> player = new SimpleObjectProperty<Player>();
    private ObjectProperty<Ship> battleship = new SimpleObjectProperty<Ship>();
    private ObjectProperty<Ship> cruiser = new SimpleObjectProperty<Ship>();
    private ObjectProperty<Ship> destroyer = new SimpleObjectProperty<Ship>();
    private ObjectProperty<Ship> submarine = new SimpleObjectProperty<Ship>();
    
    public ShipPlacement(Integer width, Integer height, Player player, Ship battleship, Ship cruiser, Ship destroyer, Ship submarine) {
        this.width.set(width);
        this.height.set(height);
        this.player.set(player);
        this.battleship.set(battleship);
        this.cruiser.set(cruiser);
        this.destroyer.set(destroyer);
        this.submarine.set(submarine);
    }
    
    public Integer getWidth() {
        return this.width.get();
    }
  
    public Integer getHeight() {
        return this.height.get();
    }

    public Player getPlayer() {
        return this.player.get();
    }
   
    public Ship getBattleship() {
        return this.battleship.get();
    }
  
    public Ship getCruiser() {
        return this.cruiser.get();
    }
  
    public Ship getDestroyer() {
        return this.destroyer.get();
    }
   
    public Ship getSubmarine() {
        return this.submarine.get();
    }

}

