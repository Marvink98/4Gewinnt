package de.volkswagen.view;

import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;

public class ShipPlacementView {
    
    private HBox rootBox;
    private VBox buttonBox;
    private VBox gridPaneBox;
    private Button battleshipButton;
    private Button cruiserButton;
    private Button destroyerButton;
    private Button submarineButton;
    private Button deleteButton;
    private Button backButton;
    private Button startTheBattleButton;
    private GridPane battleFieldGridPane;
    private Label amountShipsLabel;
    private Label amountBattleshipLabel;
    private Label amountCruiserLabel;
    private Label amountDestroyerLabel;
    private Label amountSubmarineLabel;
    private Label instructionLabel;
    private List<Button> buttonList = new ArrayList<Button>();
    private List<Button> shipButtonList = new ArrayList<Button>();
	
	public ShipPlacementView(int width, int height) {
		this.rootBox = new HBox();
		this.buttonBox = new VBox();
		this.gridPaneBox = new VBox();
		this.battleshipButton = new Button("Schlachtschiff");
		this.cruiserButton = new Button("Kreuzer");
		this.destroyerButton = new Button("Zerst�rer");
		this.submarineButton = new Button("U-Boot");
		this.deleteButton = new Button("L�schen");
		this.backButton = new Button("Zur�ck");
		this.startTheBattleButton = new Button("Bereit f�r die Schlacht");
		this.battleFieldGridPane = new GridPane();
		this.amountShipsLabel = new Label("Anzahl");
		this.amountBattleshipLabel = new Label("Nummer");
		this.amountCruiserLabel = new Label("Nummer");
		this.amountDestroyerLabel = new Label("Nummer");
		this.amountSubmarineLabel = new Label("Nummer");
		this.instructionLabel = new Label("Platziere deine Schiffe!");
		
		this.buttonBox.getChildren().addAll(this.amountShipsLabel,
				new HBox(this.battleshipButton, this.amountBattleshipLabel),
				new HBox(this.cruiserButton, this.amountCruiserLabel),
				new HBox(this.destroyerButton, this.amountDestroyerLabel),
				new HBox(this.submarineButton, this.amountSubmarineLabel),
				this.deleteButton,
				this.backButton,
				this.startTheBattleButton);
				
		this.gridPaneBox.getChildren().addAll(this.instructionLabel,
				this.battleFieldGridPane);
		
		this.rootBox.getChildren().addAll(this.buttonBox,
				this.gridPaneBox);

		this.shipButtonList.add(battleshipButton);
		this.shipButtonList.add(cruiserButton);
		this.shipButtonList.add(destroyerButton);
		this.shipButtonList.add(submarineButton);
		fillGridPane(width, height);
	}
	
	//Methode, die die GridPane f�r die ShipPlacementView erstellt
	private void fillGridPane(int rows, int columns) {
	    Button waterButton;
	    for (int i = 0; i < rows; i++) {
	        for (int j = 0; j < columns; j++) {
	            waterButton = new Button("");
	            waterButton.setMinHeight(20);
	            waterButton.setMaxHeight(20);
	            waterButton.setMinWidth(20);
	            waterButton.setMaxWidth(20);
	            
	            this.buttonList.add(waterButton);
	            this.battleFieldGridPane.add(waterButton, j, i);	
	        }
	    }	
	}
	
	// Methode, die die ShipPlacementView erzeugt
	public void createShipPlacementView(Stage primaryStage) {
	    primaryStage.setScene(new Scene(rootBox, 400, 400));
	}
	
	public Button getBattleshipButton() {
		return battleshipButton;
	}

	public Button getCruiserButton() {
		return cruiserButton;
	}

	public Button getDestroyerButton() {
		return destroyerButton;
	}

	public Button getSubmarineButton() {
		return submarineButton;
	}

	public Button getDeleteButton() {
		return deleteButton;
	}

	public Button getBackButton() {
		return backButton;
	}

	public Button getStartTheBattleButton() {
		return startTheBattleButton;
	}

	public GridPane getBattleFieldGridPane() {
		return battleFieldGridPane;
	}

	public Label getAmountShipsLabel() {
		return amountShipsLabel;
	}

	public Label getAmountBattleshipLabel() {
		return amountBattleshipLabel;
	}

	public Label getAmountCruiserLabel() {
		return amountCruiserLabel;
	}

	public Label getAmountDestroyerLabel() {
		return amountDestroyerLabel;
	}

	public Label getAmountSubmarineLabel() {
		return amountSubmarineLabel;
	}

	public List<Button> getButtonList() {
		return buttonList;
	}

	public List<Button> getShipButtonList() {
		return shipButtonList;
	}
	
}
