package de.volkswagen.view;

import javafx.scene.control.TextField;

public class NumberTextField extends TextField{
    
    // Ereugung eines Textfeldes, welches nur Zahlen annimmt

    public NumberTextField(String number) {
        super();
        this.setText(number);
    }
    
    public void replaceText(int start, int end, String text) {
        if (text.matches("[0-9]+")) {
            super.replaceText(start, end, text);
            
        }
    }
}
