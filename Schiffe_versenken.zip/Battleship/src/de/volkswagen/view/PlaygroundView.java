package de.volkswagen.view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class PlaygroundView {
	
	private HBox rootHBox = new HBox();
	private VBox intermediateBox = new VBox();
	private VBox legendVBox = new VBox();
	private VBox playFieldVBox = new VBox();
	private VBox enemyFieldVBox = new VBox();
	private VBox playerFieldVBox = new VBox();
	private VBox infoVBox = new VBox();
	private HBox infoButtonHBox = new HBox();
	private HBox infoScoreHBox = new HBox();
	private HBox infoTurnTimeHBox = new HBox();
	private HBox infoTurnCountHBox = new HBox();
	private HBox infoPlayTimeHBox = new HBox();
	private HBox infoSubmarineHBox = new HBox();
	private HBox infoCruiserHBox = new HBox();
	private HBox infoDestroyerHBox = new HBox();
	private HBox infoBattleshipHBox = new HBox();
	private HBox intactShipHBox = new HBox();
	private HBox hitShipHBox = new HBox();
	private HBox sunkShopBox = new HBox();
	private HBox waterHBox = new HBox();
	private HBox playGroundHBox = new HBox();
	private BorderPane playGroundInfoBorderPane = new BorderPane();
	private Label gameMessageLabel = new Label();
	private Label playerSiteLabel = new Label();
	private Label enemySiteLabel = new Label();
	private GridPane playerGridPane = new GridPane();
	private GridPane enemyGridPane = new GridPane();
	private Button quitButton = new Button("Beenden");
	private Button waterButton = new Button();
	private Button intactShipButton = new Button();
	private Button hitShipButton = new Button();
	private Button sunkShipButton = new Button();
	private Label legendLabel = new Label("Legende:");
	private Label waterLabel = new Label("Wasser");
	private Label intactShipLabel = new Label("Schiff intakt");
	private Label hitShipLabel = new Label("Schiff getroffen");
	private Label sunkShipLabel = new Label("Schiff versenkt");
	private Label playerBattleshipAmountLabel = new Label("1");
	private Label enemyBattleshipAmountLabel = new Label("1");
	private Label battleshipLabel = new Label("Schlachtschiff");
	private Label playerCruiserAmountLabel = new Label("2");
	private Label enemyCruiserAmountLabel = new Label("2");
	private Label cruiserLabel = new Label("Kreuzer");
	private Label playerDestroyerAmountLabel = new Label("3");
	private Label enemyDestroyerAmountLabel = new Label("3");
	private Label destroyerLabel = new Label("Zerst�rer");
	private Label playerSubmarineAmountLabel = new Label("4");
	private Label enemySubmarineAmountLabel = new Label("4");
	private Label submarineLabel = new Label("U-Boot");
	private Label playTimeLabel = new Label("Spielzeit: ");
	private Label currentPlayTimeLabel = new Label();
	private Label scoreLabel = new Label("Score: ");
	private Label currentScoreLabel = new Label("0");
	private Label turnCountLabel = new Label("Z�ge: ");
	private Label currentTurnCountLabel = new Label("1");
	private Label turnTimeLabel = new Label("Zugdauer: ");
	private Label currentTurnTimeLabel = new Label();
	private Label amountShipsLabel = new Label("Anzahl Schiffe: ");
	private Scene finalPlayground;
	private boolean init = true;
	
	public PlaygroundView() {
	    
	}

	public GridPane fillPlayerGridPane(String[][] placementPlayer) {
		playerGridPane	.getChildren()
						.clear();
		Button button;
		for (int i = 0; i < placementPlayer.length; i++) {
			for (int j = 0; j < placementPlayer[i].length; j++) {
				button = new Button();
				button.setMinHeight(20);
				button.setMaxHeight(20);
				button.setMinWidth(20);
				button.setMaxWidth(20);
				if (placementPlayer[i][j] == "water" || placementPlayer[i][j] == "shot") {
					button.setStyle("-fx-background-color: #0000FF");
					playerGridPane.add(button, i, j);
				} else if (placementPlayer[i][j] == "ship") {
					button.setStyle("-fx-background-color: #00FF00");
					playerGridPane.add(button, i, j);
				} else if(placementPlayer[i][j] == "hit"){
					button.setStyle("-fx-background-color: #FFFF00");
					playerGridPane.add(button, i, j);
				} else {
					button.setStyle("-fx-background-color: #FF0000");
					playerGridPane.add(button, i, j);
				}
			}
		}
		return this.playerGridPane;
	}

	public GridPane fillEnemyGridPane(String[][] placementEnemy) {
		enemyGridPane	.getChildren()
						.clear();
		Button button;
		for (int i = 0; i < placementEnemy.length; i++) {
			for (int j = 0; j < placementEnemy[i].length; j++) {
				button = new Button();
		        button.setMinHeight(20);
		        button.setMaxHeight(20);
		        button.setMinWidth(20);
		        button.setMaxWidth(20);
				if (placementEnemy[i][j] == "water") {
					enemyGridPane.add(button, i, j);
				} else if (placementEnemy[i][j] == "ship") {
					enemyGridPane.add(button, i, j);
				} else if (placementEnemy[i][j] == "hit"){
					button.setStyle("-fx-background-color: #FFFF00");
					enemyGridPane.add(button, i, j);
				} else if (placementEnemy[i][j] == "shot"){
					button.setStyle("-fx-background-color: #0000FF");
					enemyGridPane.add(button, i, j);
				} else {
					button.setStyle("-fx-background-color: #FF0000");
					enemyGridPane.add(button, i, j);
				}
			}
		}
		return this.enemyGridPane;
	}

	public VBox createPlaygroundView(String[][] placementPlayer, String[][] placementEnemy) {
		infoBattleshipHBox	.getChildren()
							.clear();
		infoBattleshipHBox	.getChildren()
							.addAll(playerBattleshipAmountLabel, battleshipLabel, enemyBattleshipAmountLabel);
		infoCruiserHBox	.getChildren()
						.clear();
		infoCruiserHBox	.getChildren()
						.addAll(playerCruiserAmountLabel, cruiserLabel, enemyCruiserAmountLabel);
		infoDestroyerHBox	.getChildren()
							.clear();
		infoDestroyerHBox	.getChildren()
							.addAll(playerDestroyerAmountLabel, destroyerLabel, enemyDestroyerAmountLabel);
		infoSubmarineHBox	.getChildren()
							.clear();
		infoSubmarineHBox	.getChildren()
							.addAll(playerSubmarineAmountLabel, submarineLabel, enemySubmarineAmountLabel);
		infoPlayTimeHBox.getChildren()
						.clear();
		infoPlayTimeHBox.getChildren()
						.addAll(playTimeLabel, currentPlayTimeLabel);
		infoTurnTimeHBox.getChildren()
						.clear();
		infoTurnTimeHBox.getChildren()
						.addAll(turnTimeLabel, currentTurnTimeLabel);
		infoTurnCountHBox	.getChildren()
							.clear();
		infoTurnCountHBox	.getChildren()
							.addAll(turnCountLabel, currentTurnCountLabel);
		infoScoreHBox	.getChildren()
						.clear();
		infoScoreHBox	.getChildren()
						.addAll(scoreLabel, currentScoreLabel);
		infoButtonHBox	.getChildren()
						.clear();
		infoButtonHBox	.getChildren()
						.add(quitButton);
		infoVBox.getChildren()
				.clear();
		infoVBox.getChildren()
				.addAll(amountShipsLabel, infoBattleshipHBox, infoCruiserHBox, infoDestroyerHBox, infoSubmarineHBox,
						infoPlayTimeHBox, infoTurnTimeHBox, infoTurnCountHBox, infoScoreHBox, infoButtonHBox);

		enemyFieldVBox	.getChildren()
						.clear();
		enemyFieldVBox	.getChildren()
						.addAll(enemySiteLabel, fillEnemyGridPane(placementEnemy));
		playerFieldVBox	.getChildren()
						.clear();
		playerFieldVBox	.getChildren()
						.addAll(playerSiteLabel, fillPlayerGridPane(placementPlayer));
		playGroundHBox	.getChildren()
						.clear();
		playGroundHBox	.getChildren()
						.addAll(playerFieldVBox, infoVBox, enemyFieldVBox);
		playGroundInfoBorderPane.getChildren().clear();
		playGroundInfoBorderPane  .setCenter(gameMessageLabel);
		playGroundInfoBorderPane  .setRight(createLegendView());
		playFieldVBox	.getChildren()
						.clear();
		playFieldVBox	.getChildren()
						.addAll(playGroundHBox, playGroundInfoBorderPane);
		return playFieldVBox;
	}

	public VBox createPlaygroundViewMirrored(String[][] placementPlayer, String[][] placementEnemy) {
		infoBattleshipHBox	.getChildren()
							.clear();
		infoBattleshipHBox	.getChildren()
							.addAll(enemyBattleshipAmountLabel, battleshipLabel, playerBattleshipAmountLabel);
		infoCruiserHBox	.getChildren()
						.clear();
		infoCruiserHBox	.getChildren()
						.addAll(enemyCruiserAmountLabel, cruiserLabel, playerCruiserAmountLabel);

		infoDestroyerHBox	.getChildren()
							.clear();
		infoDestroyerHBox	.getChildren()
							.addAll(enemyDestroyerAmountLabel, destroyerLabel, playerDestroyerAmountLabel);
		infoSubmarineHBox	.getChildren()
							.clear();
		infoSubmarineHBox	.getChildren()
							.addAll(enemySubmarineAmountLabel, submarineLabel, playerSubmarineAmountLabel);
		infoPlayTimeHBox.getChildren()
						.clear();
		infoPlayTimeHBox.getChildren()
						.addAll(playTimeLabel, currentPlayTimeLabel);
		infoTurnTimeHBox.getChildren()
						.clear();
		infoTurnTimeHBox.getChildren()
						.addAll(turnTimeLabel, currentTurnTimeLabel);
		infoTurnCountHBox	.getChildren()
							.clear();
		infoTurnCountHBox	.getChildren()
							.addAll(turnCountLabel, currentTurnCountLabel);
		infoScoreHBox	.getChildren()
						.clear();
		infoScoreHBox	.getChildren()
						.addAll(scoreLabel, currentScoreLabel);
		infoButtonHBox	.getChildren()
						.clear();
		infoButtonHBox	.getChildren()
						.add(quitButton);
		infoVBox.getChildren()
				.clear();
		infoVBox.getChildren()
				.addAll(amountShipsLabel, infoBattleshipHBox, infoCruiserHBox, infoDestroyerHBox, infoSubmarineHBox,
						infoPlayTimeHBox, infoTurnTimeHBox, infoTurnCountHBox, infoScoreHBox, infoButtonHBox);

		enemyFieldVBox	.getChildren()
						.clear();
		enemyFieldVBox	.getChildren()
						.addAll(playerSiteLabel, fillPlayerGridPane(placementEnemy));
		playerFieldVBox	.getChildren()
						.clear();
		playerFieldVBox	.getChildren()
						.addAll(enemySiteLabel, fillEnemyGridPane(placementPlayer));
		playGroundHBox	.getChildren()
						.clear();
		playGroundHBox	.getChildren()
						.addAll(enemyFieldVBox, infoVBox, playerFieldVBox);
		playGroundInfoBorderPane.getChildren().clear();
		playGroundInfoBorderPane  .setLeft(gameMessageLabel);
        playGroundInfoBorderPane  .setRight(createLegendView());
		playFieldVBox	.getChildren()
						.clear();
		playFieldVBox	.getChildren()
						.addAll(playGroundHBox, playGroundInfoBorderPane);
		return playFieldVBox;
	}

	public VBox createLegendView() {
	    waterButton.setStyle("-fx-background-color: #0000FF");
        intactShipButton.setStyle("-fx-background-color: #00FF00");
        hitShipButton.setStyle("-fx-background-color: #FFFF00");
        sunkShipButton.setStyle("-fx-background-color: #FF0000");
		intactShipHBox	.getChildren()
						.clear();
		intactShipHBox	.getChildren()
						.addAll(intactShipButton, intactShipLabel);
		hitShipHBox	.getChildren()
					.clear();
		hitShipHBox	.getChildren()
					.addAll(hitShipButton, hitShipLabel);
		sunkShopBox	.getChildren()
					.clear();
		sunkShopBox	.getChildren()
					.addAll(sunkShipButton, sunkShipLabel);
		waterHBox	.getChildren()
					.clear();
		waterHBox	.getChildren()
					.addAll(waterButton, waterLabel);
		legendVBox	.getChildren()
					.clear();
		legendVBox	.getChildren()
					.addAll(legendLabel, intactShipHBox, hitShipHBox, sunkShopBox, waterHBox);
		return legendVBox;
	}

	public Scene createPlaygroundViewWithLegend(String[][] placementPlayer, String[][] placementEnemy) {
		rootHBox.getChildren()
				.clear();
		rootHBox.getChildren()
				.add(createPlaygroundView(placementPlayer, placementEnemy));
		if (this.init) {
			setFinalPlayground(new Scene(rootHBox, 800, 400));
			this.init = false;
		}
		return this.finalPlayground;
	}

	public Scene createPlaygroundViewWithLegendMirrored(String[][] placementPlayer, String[][] placementEnemy) {
		rootHBox.getChildren()
				.clear();
		rootHBox.getChildren()
				.add(createPlaygroundViewMirrored(placementPlayer, placementEnemy));
		if (this.init) {
			setFinalPlayground(new Scene(rootHBox, 800, 400));
			this.init = false;
		}
		return this.finalPlayground;
	}

	public void createIntermediateViewToPlayer() {
		rootHBox.getChildren()
				.clear();
		intermediateBox = new VBox(new Label("Der Spieler ist am Zug"), new Label("Enter dr�cken um fortzufahren"));
		rootHBox.getChildren()
				.add(intermediateBox);
	}

	public void createIntermediateViewToEnemy() {
		rootHBox.getChildren()
				.clear();
		intermediateBox = new VBox(new Label("Der Gegner ist am Zug"), new Label("Enter dr�cken um fortzufahren"));
		rootHBox.getChildren()
				.add(intermediateBox);
	}

	public HBox getRootHBox() {
		return rootHBox;
	}

	public void setRootHBox(HBox rootHBox) {
		this.rootHBox = rootHBox;
	}

	public VBox getLegendVBox() {
		return legendVBox;
	}

	public void setLegendVBox(VBox legendVBox) {
		this.legendVBox = legendVBox;
	}

	public VBox getPlayFieldVBox() {
		return playFieldVBox;
	}

	public void setPlayFieldVBox(VBox playFieldVBox) {
		this.playFieldVBox = playFieldVBox;
	}

	public VBox getEnemyFielVBox() {
		return enemyFieldVBox;
	}

	public void setEnemyFielVBox(VBox enemyFielVBox) {
		this.enemyFieldVBox = enemyFielVBox;
	}

	public VBox getPlayerFieldVBox() {
		return playerFieldVBox;
	}

	public void setPlayerFieldVBox(VBox playerFieldVBox) {
		this.playerFieldVBox = playerFieldVBox;
	}

	public VBox getInfoVBox() {
		return infoVBox;
	}

	public void setInfoVBox(VBox infoVBox) {
		this.infoVBox = infoVBox;
	}

	public HBox getInfoButtonHBox() {
		return infoButtonHBox;
	}

	public void setInfoButtonHBox(HBox infoButtonHBox) {
		this.infoButtonHBox = infoButtonHBox;
	}

	public HBox getInfoScoreHBox() {
		return infoScoreHBox;
	}

	public void setInfoScoreHBox(HBox infoScoreHBox) {
		this.infoScoreHBox = infoScoreHBox;
	}

	public HBox getInfoTurnTimeHBox() {
		return infoTurnTimeHBox;
	}

	public void setInfoTurnTimeHBox(HBox infoTurnTimeHBox) {
		this.infoTurnTimeHBox = infoTurnTimeHBox;
	}

	public HBox getInfoTurnCountHBox() {
		return infoTurnCountHBox;
	}

	public void setInfoTurnCountHBox(HBox infoTurnCountHBox) {
		this.infoTurnCountHBox = infoTurnCountHBox;
	}

	public HBox getInfoPlayTimeHBox() {
		return infoPlayTimeHBox;
	}

	public void setInfoPlayTimeHBox(HBox infoPlayTimeHBox) {
		this.infoPlayTimeHBox = infoPlayTimeHBox;
	}

	public HBox getInfoSubmarineHBox() {
		return infoSubmarineHBox;
	}

	public void setInfoSubmarineHBox(HBox infoSubmarineHBox) {
		this.infoSubmarineHBox = infoSubmarineHBox;
	}

	public HBox getInfoCruiserHBox() {
		return infoCruiserHBox;
	}

	public void setInfoCruiserHBox(HBox infoCruiserHBox) {
		this.infoCruiserHBox = infoCruiserHBox;
	}

	public HBox getInfoDestroyerHBox() {
		return infoDestroyerHBox;
	}

	public void setInfoDestroyerHBox(HBox infoDestroyerHBox) {
		this.infoDestroyerHBox = infoDestroyerHBox;
	}

	public HBox getInfoBattleshipHBox() {
		return infoBattleshipHBox;
	}

	public void setInfoBattleshipHBox(HBox infoBattleshipHBox) {
		this.infoBattleshipHBox = infoBattleshipHBox;
	}

	public HBox getPlayGroundHBox() {
		return playGroundHBox;
	}

	public void setPlayGroundHBox(HBox playGroundHBox) {
		this.playGroundHBox = playGroundHBox;
	}

	public Label getGameMessageLabel() {
		return gameMessageLabel;
	}

	public void setGameMessageLabel(String gameMessage) {
		this.gameMessageLabel.setText(gameMessage);
	}

	public Label getPlayerSiteLabel() {
		return playerSiteLabel;
	}

	public void setPlayerSiteLabel(String playerSite) {
		this.playerSiteLabel.setText(playerSite);
	}

	public Label getEnemySiteLabel() {
		return enemySiteLabel;
	}

	public void setEnemySiteLabel(String enemySite) {
		this.enemySiteLabel.setText(enemySite);
	}

	public GridPane getPlayerGridPane() {
		return playerGridPane;
	}

	public void setPlayerGridPane(GridPane playerGridPane) {
		this.playerGridPane = playerGridPane;
	}

	public GridPane getEnemyGridPane() {
		return enemyGridPane;
	}

	public void setEnemyGridPane(GridPane enemyGridPane) {
		this.enemyGridPane = enemyGridPane;
	}


	public Button getQuitButton() {
		return quitButton;
	}

	public void setQuitButton(Button quitButton) {
		this.quitButton = quitButton;
	}

	public Button getWaterButton() {
		return waterButton;
	}

	public void setWaterButton(Button waterButton) {
		this.waterButton = waterButton;
	}

	public Button getIntactShipButton() {
		return intactShipButton;
	}

	public void setIntactShipButton(Button intactShipButton) {
		this.intactShipButton = intactShipButton;
	}

	public Button getHitShipButton() {
		return hitShipButton;
	}

	public void setHitShipButton(Button hitShipButton) {
		this.hitShipButton = hitShipButton;
	}

	public Button getSunkShipButton() {
		return sunkShipButton;
	}

	public void setSunkShipButton(Button sunkShipButton) {
		this.sunkShipButton = sunkShipButton;
	}

	public Label getLegendLabel() {
		return legendLabel;
	}

	public void setLegendLabel(String legend) {
		this.legendLabel.setText(legend);
	}

	public Label getWaterLabel() {
		return waterLabel;
	}

	public void setWaterLabel(String water) {
		this.waterLabel.setText(water);
	}

	public Label getIntactShipLabel() {
		return intactShipLabel;
	}

	public void setIntactShipLabel(String intactShip) {
		this.intactShipLabel.setText(intactShip);
	}

	public Label getHitShipLabel() {
		return hitShipLabel;
	}

	public void setHitShipLabel(String hitShip) {
		this.hitShipLabel.setText(hitShip);
	}

	public Label getSunkShipLabel() {
		return sunkShipLabel;
	}

	public void setSunkShipLabel(String sunkShip) {
		this.sunkShipLabel.setText(sunkShip);
	}

	public Label getPlayerBattleshipAmountLabel() {
		return playerBattleshipAmountLabel;
	}

	public void setPlayerBattleshipAmountLabel(String playerBattleshipAmount) {
		this.playerBattleshipAmountLabel.setText(playerBattleshipAmount);
	}

	public Label getEnemyBattleshipAmountLabel() {
		return enemyBattleshipAmountLabel;
	}

	public void setEnemyBattleshipAmountLabel(String enemyBattleshipAmount) {
		this.enemyBattleshipAmountLabel.setText(enemyBattleshipAmount);
	}

	public Label getBattleshipLabel() {
		return battleshipLabel;
	}

	public void setBattleshipLabel(String battleship) {
		this.battleshipLabel.setText(battleship);
	}

	public Label getPlayerCruiserAmountLabel() {
		return playerCruiserAmountLabel;
	}

	public void setPlayerCruiserAmountLabel(String playerCruiserAmount) {
		this.playerCruiserAmountLabel.setText(playerCruiserAmount);
	}

	public Label getEnemyCruiserAmountLabel() {
		return enemyCruiserAmountLabel;
	}

	public void setEnemyCruiserAmountLabel(String enemyCruiserAmount) {
		this.enemyCruiserAmountLabel.setText(enemyCruiserAmount);
	}

	public Label getCruiserLabel() {
		return cruiserLabel;
	}

	public void setCruiserLabel(String cruiser) {
		this.cruiserLabel.setText(cruiser);
	}

	public Label getPlayerDestroyerAmountLabel() {
		return playerDestroyerAmountLabel;
	}

	public void setPlayerDestroyerAmountLabel(String playerDestroyerAmount) {
		this.playerDestroyerAmountLabel.setText(playerDestroyerAmount);
	}

	public Label getEnemyDestroyerAmountLabel() {
		return enemyDestroyerAmountLabel;
	}

	public void setEnemyDestroyerAmountLabel(String enemyDestroyerAmount) {
		this.enemyDestroyerAmountLabel.setText(enemyDestroyerAmount);
	}

	public Label getDestroyerLabel() {
		return destroyerLabel;
	}

	public void setDestroyerLabel(String destroyer) {
		this.destroyerLabel.setText(destroyer);
	}

	public Label getPlayerSubmarineAmountLabel() {
		return playerSubmarineAmountLabel;
	}

	public void setPlayerSubmarineAmountLabel(String playerSubmarineAmount) {
		this.playerSubmarineAmountLabel.setText(playerSubmarineAmount);
	}

	public Label getEnemySubmarineAmountLabel() {
		return enemySubmarineAmountLabel;
	}

	public void setEnemySubmarineAmountLabel(String enemySubmarineAmount) {
		this.enemySubmarineAmountLabel.setText(enemySubmarineAmount);
	}

	public Label getSubmarineLabel() {
		return submarineLabel;
	}

	public void setSubmarineLabel(String submarine) {
		this.submarineLabel.setText(submarine);
	}

	public Label getPlayTimeLabel() {
		return playTimeLabel;
	}

	public void setPlayTimeLabel(String playTime) {
		this.playTimeLabel.setText(playTime);
	}

	public Label getCurrentPlayTimeLabel() {
		return currentPlayTimeLabel;
	}

	public void setCurrentPlayTimeLabel(String currentPlayTime) {
		this.currentPlayTimeLabel.setText(currentPlayTime);
	}

	public Label getScoreLabel() {
		return scoreLabel;
	}

	public void setScoreLabel(String score) {
		this.scoreLabel.setText(score);
	}

	public Label getCurrentScoreLabel() {
		return currentScoreLabel;
	}

	public void setCurrentScoreLabel(String currentScore) {
		this.currentScoreLabel.setText(currentScore);
	}

	public Label getTurnCountLabel() {
		return turnCountLabel;
	}

	public void setTurnCountLabel(String turnCount) {
		this.turnCountLabel.setText(turnCount);
	}

	public Label getCurrentTurnCountLabel() {
		return currentTurnCountLabel;
	}

	public void setCurrentTurnCountLabel(String currentTurnCount) {
		this.currentTurnCountLabel.setText(currentTurnCount);
	}

	public Label getTurnTimeLabel() {
		return turnTimeLabel;
	}

	public void setTurnTimeLabel(String turnTime) {
		this.turnTimeLabel.setText(turnTime);
	}

	public Label getCurrentTurnTimeLabel() {
		return currentTurnTimeLabel;
	}

	public void setCurrentTurnTimeLabel(String currentTurnTime) {
		this.currentTurnTimeLabel.setText(currentTurnTime);
	}

	public Label getAmountShipsLabel() {
		return amountShipsLabel;
	}

	public void setAmountShipsLabel(String amountShips) {
		this.amountShipsLabel.setText(amountShips);
	}

	public VBox getIntermediateBox() {
		return intermediateBox;
	}

	public void setIntermediateBox(VBox intermediateBox) {
		this.intermediateBox = intermediateBox;
	}

	public Scene getFinalPlayground() {
		return finalPlayground;
	}

	public Scene setFinalPlayground(Scene finalPlayground) {
		this.finalPlayground = finalPlayground;
		return finalPlayground;
	}

}
