package de.volkswagen.view;

import de.volkswagen.database.DBUtils;
import de.volkswagen.model.Player;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class StartView {
	
	private Button tutorialButton;
	private Button playerOneButton;
	private Button playerTwoButton;
	private Button highscoreButton;
	private Button startButton;
	private TableView<Player> highscoreTableView;
	private TextField namePlayerOneField;
	private TextField namePlayerTwoField;
	private NumberTextField heightField;
	private NumberTextField widthField;
	private Label nameOneLabel;
	private Label nameTwoLabel;
	private Label chooseSizeLabel;
	private Label amountShipsLabel;
	private Label battleShipLabel;
	private Label cruiserLabel;
	private Label destroyerLabel;
	private Label submarineLabel;
	private NumberTextField amountBattleshipsField;
	private NumberTextField amountCruiserField;
	private NumberTextField amountDestroyerField;
	private NumberTextField amountSubmarineField;
	private Label heightLabel;
	private Label widthLabel;
	private HBox rootBox;
	private VBox buttonBox;
	private VBox onePlayerBox;
	private VBox twoPlayerBox;
	private VBox highscoreBox;
	private VBox tutorialBox;
	private Label tutorialLabel;
	private ObservableList<Player> highscoreList = DBUtils.getAllPlayers();
	
	private final String TUTORIALTEXT = 
	                "Spielanleitung: \n" +
	                        "\n" +
	                        "Um gegen den Computer zu spielen, w�hlt man '1 Spieler' aus.\n" +
	                        "\n" +
	                        "Um eine Partie gegen eine andere Person zu spielen '2 Spieler'. \n" +
	                        "\n" +
	                        "Gebt die Namen, die gew�nschte Spielfeldgr��e und die Anzahl \n" +
	                        "der Schiffe ein. \n" +
	                        "Mit dem Dr�cken des 'Start-Buttons' k�nnt ihr nacheinander \n" +
	                        "eure Schiffe platzieren. \n" +
	                        "Seid ihr damit fertig dr�ckt: 'Lass die Schlacht beginnen'. \n" +
	                        "\n" +
	                        "Folgende Platzierungsregeln m�ssen eingehalten werden: \n" +
	                        "1. Die Schiffe d�rfen nicht an einandersto�en \n" +
	                        "2. Die Schiffe d�rfen nicht �ber Eck gebaut sein \n" +
	                        "3. Die Schiffe d�rfen keine Ausbuchtungen besitzen \n" +
	                        "4. Schiffe d�rfen auch am Rand liegen \n" +
	                        "5. Schiffe d�rfen nicht diagonal aufgestellt werden \n" +
	                        "\n" +
	                        "Anschlie�end baut sich das Spielfeld auf. \n" +
	                        "Man sieht links seine eigenen Schiffe und kann rechts \n" +
	                        "mit Klick auf die Felder den Gegner beschie�en. \n" +
	                        "Hat eine Seite alle Schiffe der anderen verenkt, ist sie der Gewinner \n" +
	                        "und das Spiel ist beendet. \n" +
	                        "Viel Spa� in der Schlacht ;)";
	
	
	
	//Der Inhalt aller Elemente die man sieht werden im Konstruktor erstellt
	public StartView() {
		this.tutorialButton = new Button("Tutorial");
		this.playerOneButton = new Button("1 Spieler");
		this.playerTwoButton = new Button("2 Spieler");
		this.highscoreButton = new Button("Highscore");
		this.startButton = new Button("Starten");
		this.highscoreTableView = new TableView<Player>();
		this.namePlayerOneField = new TextField();
		this.namePlayerOneField.setPromptText("Name");
		this.namePlayerTwoField = new TextField();
		this.namePlayerTwoField.setPromptText("Name");
		this.heightField = new NumberTextField("10");
		this.widthField = new NumberTextField("10");
		this.nameOneLabel = new Label("Namen eingeben");
		this.nameTwoLabel = new Label("Namen eingeben");
		this.chooseSizeLabel = new Label("W�hle die Spielfeldgr��e (5-50):");
		this.amountShipsLabel = new Label("Anzahl Schiffe");
		this.battleShipLabel = new Label("Schlachtschiffe:");
		this.cruiserLabel = new Label("Kreuzer:");
		this.destroyerLabel = new Label("Zerst�rer:");
		this.submarineLabel = new Label("U-Boot:");
		this.amountBattleshipsField = new NumberTextField("1");
		this.amountCruiserField = new NumberTextField("2");
		this.amountDestroyerField = new NumberTextField("3");
		this.amountSubmarineField = new NumberTextField("4");
		this.heightLabel = new Label("H�he: ");
		this.widthLabel = new Label("Breite: ");
		this.rootBox = new HBox();
		this.buttonBox = new VBox();
		this.onePlayerBox = new VBox();
		this.twoPlayerBox = new VBox();
		this.highscoreBox = new VBox();
		this.tutorialBox = new VBox();
		this.tutorialLabel = new Label(TUTORIALTEXT);
		/*
		Bis hierhin geht die Erstellung der Inhalte, im restlichen Teil
		des Konstruktors geht es nur noch um die Zusammensetzung der Elemente
		*/
		this.buttonBox.getChildren().addAll(
				this.tutorialButton,
				this.playerOneButton,
				this.playerTwoButton,
				this.highscoreButton
				);
		
		this.twoPlayerBox.getChildren().addAll(
				new HBox(this.nameOneLabel, this.nameTwoLabel),
				new HBox(this.namePlayerOneField, this.namePlayerTwoField),
				this.chooseSizeLabel,
				new HBox(this.heightLabel, this.heightField, this.widthLabel, this.widthField),
				this.amountShipsLabel,
				new HBox(this.battleShipLabel, this.amountBattleshipsField),
				new HBox(this.cruiserLabel, this.amountCruiserField),
				new HBox(this.destroyerLabel, this.amountDestroyerField),
				new HBox(this.submarineLabel, this.amountSubmarineField),
				this.startButton
				);
		
		this.onePlayerBox.getChildren().addAll(
				new HBox(this.nameOneLabel),
				new HBox(this.namePlayerOneField),
				this.chooseSizeLabel,
				new HBox(this.heightLabel, this.heightField, this.widthLabel, this.widthField),
				this.amountShipsLabel,
				new HBox(this.battleShipLabel, this.amountBattleshipsField),
				new HBox(this.cruiserLabel, this.amountCruiserField),
				new HBox(this.destroyerLabel, this.amountDestroyerField),
				new HBox(this.submarineLabel, this.amountSubmarineField),
				this.startButton
				);
		
		this.tutorialBox.getChildren().addAll(this.tutorialLabel);
		this.highscoreBox.getChildren().addAll(createTableView());
	}
	
	// Methode, die die OnePlayerBox mit Elementen f�llt
	private VBox fillOnePlayerBox() {
		this.onePlayerBox.getChildren().clear();
		this.onePlayerBox.getChildren().addAll(
			new HBox(this.nameOneLabel),
			new HBox(this.namePlayerOneField),
			this.chooseSizeLabel,
			new HBox(this.heightLabel, this.heightField, this.widthLabel, this.widthField),
			this.amountShipsLabel,
			new HBox(this.battleShipLabel, this.amountBattleshipsField),
			new HBox(this.cruiserLabel, this.amountCruiserField),
			new HBox(this.destroyerLabel, this.amountDestroyerField),
			new HBox(this.submarineLabel, this.amountSubmarineField),
			this.startButton
			);
		return this.onePlayerBox;
	}
	
	// Methode, die die TwoPlayerBox mit Elementen f�llt
	private VBox fillTwoPlayerBox() {
		this.twoPlayerBox.getChildren().clear();
		this.twoPlayerBox.getChildren().addAll(
				new HBox(this.nameOneLabel, this.nameTwoLabel),
				new HBox(this.namePlayerOneField, this.namePlayerTwoField),
				this.chooseSizeLabel,
				new HBox(this.heightLabel, this.heightField, this.widthLabel, this.widthField),
				this.amountShipsLabel,
				new HBox(this.battleShipLabel, this.amountBattleshipsField),
				new HBox(this.cruiserLabel, this.amountCruiserField),
				new HBox(this.destroyerLabel, this.amountDestroyerField),
				new HBox(this.submarineLabel, this.amountSubmarineField),
				this.startButton
				);
	return this.twoPlayerBox;
	}

	// Methode, die die Willkommensansicht erzeugt
	public Scene createStartView() {
		this.rootBox.getChildren().add(this.buttonBox);
		this.rootBox.getChildren().add(new Label("Willkommen"));
		return new Scene(this.rootBox, 500, 450);
	}
	
	// Methode, die die 1-Spieler Eingabemaske erzeugt
	public void createOnePlayerView() {
		this.rootBox.getChildren().remove(1);
		this.rootBox.getChildren().add(fillOnePlayerBox());
	}
	
	// Methode, die die 2-Spieler Eingabemaske erzeugt
	public void createTwoPlayerView() {
		this.rootBox.getChildren().remove(1);
		this.rootBox.getChildren().add(fillTwoPlayerBox());
	}
	
	// Methode, die die HighscoreView erzeugt
	public void createHighscoreView() {
		this.rootBox.getChildren().remove(1);
		this.rootBox.getChildren().add(this.highscoreBox);
	}
	
	// Methode, die die Spielanleitungsansicht erzeugt
	public void createTutorialView() {
		this.rootBox.getChildren().remove(1);
		this.rootBox.getChildren().add(this.tutorialBox);
	}
	
	
	// Methode erzeugt die TableView
	public TableView<Player> createTableView() {
	    
	    TableColumn<Player, String> nameColumn = new TableColumn<>("Name");
	    TableColumn<Player, Integer> scoreColumn = new TableColumn<>("Punktestand");
	    TableColumn<Player, Integer> turnColumn = new TableColumn<>("Z�ge");
	    
	    nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
	    scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));
	    turnColumn.setCellValueFactory(new PropertyValueFactory<>("turns"));
	    
	    highscoreTableView.getColumns().add(nameColumn);
	    highscoreTableView.getColumns().add(scoreColumn);
	    highscoreTableView.getColumns().add(turnColumn);
	    highscoreTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
	    
	    highscoreTableView.getItems().addAll(highscoreList);
	    
	    return highscoreTableView;
	}
	
	public Button getTutorialButton() {
		return tutorialButton;
	}

	public Button getPlayerOneButton() {
		return playerOneButton;
	}

	public Button getPlayerTwoButton() {
		return playerTwoButton;
	}
	
	public Button getHighscoreButton() {
		return highscoreButton;
	}
	
	public Button getStartButton() {
		return startButton;
	}

	public TextField getNamePlayerOneField() {
		return namePlayerOneField;
	}

	public TextField getNamePlayerTwoField() {
		return namePlayerTwoField;
	}
	
	public TextField getHeight() {
		return heightField;
	}
	
	public TextField getWidth() {
		return widthField;
	}
	
	public TextField getAmountBattleshipsField() {
		return amountBattleshipsField;
	}

	public TextField getAmountCruiserField() {
		return amountCruiserField;
	}
	
	public TextField getAmountDestroyerField() {
		return amountDestroyerField;
	}
	
	public TextField getAmountSubmarineField() {
		return amountSubmarineField;
	}
	
}
