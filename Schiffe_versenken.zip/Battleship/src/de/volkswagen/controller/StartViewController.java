package de.volkswagen.controller;

import de.volkswagen.model.Player;
import de.volkswagen.model.Ship;
import de.volkswagen.model.ShipPlacement;
import de.volkswagen.view.StartView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class StartViewController {
    
    private ShipPlacement shipPlacementPlayer;
    private ShipPlacement shipPlacementEnemy;
    private Player player;
    private Player enemy;
    private StartView startView = new StartView();
    private Stage primaryStage = new Stage();
    private int whichButton;
    
    public StartViewController(StartView startView) {
        this.startView = startView;
        clickStartButton();
        clickTutorialButton();
        clickPlayerOneButton();
        clickPlayerTwoButton();
        clickHighscoreButton();
    }
    
    // Methode, die die StartView ansicht aufbaut
    public Scene start(Stage primaryStage) {
        this.primaryStage = primaryStage;
    	return this.startView.createStartView();
    }
    
    // Methoden, die aus den eingegebenen Namen die 2 Player/1 Player vs. "Computer" erstellt
    public void createPlayer() {
        player = new Player(startView.getNamePlayerOneField().getText());
    }
    
    public void createEnemy() {
        if (whichButton == 1) {
            enemy = new Player("Computer");
        } else {
            enemy = new Player(startView.getNamePlayerTwoField().getText());
        }
    }
    
    // Methoden, die das ShipPlacement des 2 Player erstellt
    public ShipPlacement createShipPlacementPlayer() {
        this.shipPlacementPlayer = new ShipPlacement(Integer.parseInt(startView.getWidth().getText()),
                Integer.parseInt(startView.getHeight().getText()),
                this.player,
                new Ship(Integer.parseInt(startView.getAmountBattleshipsField().getText()), "battleship"),
                new Ship(Integer.parseInt(startView.getAmountCruiserField().getText()), "cruiser"), 
                new Ship(Integer.parseInt(startView.getAmountDestroyerField().getText()),"destroyer"), 
                new Ship(Integer.parseInt(startView.getAmountSubmarineField().getText()), "submarine"));
        return this.shipPlacementPlayer;
    }
    
    public ShipPlacement createShipPlacementEnemy() {
        this.shipPlacementEnemy = new ShipPlacement(Integer.parseInt(startView.getWidth().getText()), 
                Integer.parseInt(startView.getHeight().getText()),
                this.enemy,
                new Ship(Integer.parseInt(startView.getAmountBattleshipsField().getText()), "battleship"),
                new Ship(Integer.parseInt(startView.getAmountCruiserField().getText()), "cruiser"), 
                new Ship(Integer.parseInt(startView.getAmountDestroyerField().getText()),"destroyer"), 
                new Ship(Integer.parseInt(startView.getAmountSubmarineField().getText()), "submarine"));
        return this.shipPlacementEnemy;
    }
    
    // Methode, die beim Anklicken des Start-Buttons die Player, diie ShipPlacements erstellt und in die n�chste Ansicht ShipPlacmentView wechslt, indem sie einen neuen ShipPlacementViewController erzeugt
    public void clickStartButton() {
        this.startView.getStartButton().setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {

                createPlayer();
                createEnemy();
                
                ShipPlacementViewController shipPlacementViewController = new ShipPlacementViewController(createShipPlacementPlayer(), createShipPlacementEnemy(), primaryStage, whichButton);
                shipPlacementViewController.createShipPlacementViewPlayer();
            }
        });
    }
    
    // Methode, die beim Anklicken des Tutorial-Buttons die Spielregeln anzeigt
    public void clickTutorialButton() {
        this.startView.getTutorialButton().setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                startView.createTutorialView();
            }
        });
    }
    
    // Methode, die beim Anklicken des 1 Spieler Buttons die Eingabemaske f�r einen Spieler anzeigt
    public void clickPlayerOneButton() {
        this.startView.getPlayerOneButton().setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                whichButton = 1;
                startView.createOnePlayerView();
                
            }
        });
    }
    
    // Methode, die beim Anklicken des 2 Spieler Buttons die Eingabemaske f�r zwei Spieler anzeigt
    public void clickPlayerTwoButton() {
        this.startView.getPlayerTwoButton().setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                whichButton = 2;
                startView.createTwoPlayerView();
            }
        });
    }
    
    // Methode, die beim Anklicken des Highscore-Buttons die Highscoretablelle mit den daten aus der Datenbank anzeigt
    public void clickHighscoreButton() {
        this.startView.getHighscoreButton().setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                startView.createHighscoreView();
            }
        });
    }
    
}
