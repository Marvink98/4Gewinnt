package de.volkswagen.controller;

import de.volkswagen.model.Player;
import de.volkswagen.model.Playground;
import de.volkswagen.model.ShipPlacement;
import de.volkswagen.view.ShipPlacementView;
import de.volkswagen.view.StartView;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ShipPlacementViewController {
	
	private Player player;
	private Player enemy;
    private ShipPlacement shipPlacementPlayer;
    private ShipPlacementView shipPlacementViewPlayer;
    private String[][] placementPlayer;
    private ShipPlacement shipPlacementEnemy;
    private ShipPlacementView shipPlacementViewEnemy;
    private String[][] placementEnemy;
    private Stage primaryStage;
    private int whichGameModus;
    private int originallyAmountBattleShips;
    private int originallyAmountCruiser;
    private int originallyAmountDestroyer;
    private int originallyAmountSubmarine;
    private boolean placementActive = false;
    
    public ShipPlacementViewController(ShipPlacement shipPlacementPlayer, ShipPlacement shipPlacementEnemy, Stage primaryStage, int whichGameModus) {
        this.shipPlacementPlayer = shipPlacementPlayer;
        this.shipPlacementViewPlayer = new ShipPlacementView(shipPlacementPlayer.getWidth(), shipPlacementPlayer.getHeight());
        this.shipPlacementEnemy = shipPlacementEnemy;
        this.shipPlacementViewEnemy = new ShipPlacementView(shipPlacementEnemy.getWidth(), shipPlacementEnemy.getHeight());
        this.player = shipPlacementPlayer.getPlayer();
        this.enemy = shipPlacementEnemy.getPlayer();
        this.primaryStage = primaryStage;
        this.whichGameModus = whichGameModus;
        this.originallyAmountBattleShips = shipPlacementPlayer.getBattleship().getAmount();
        this.originallyAmountCruiser = shipPlacementPlayer.getCruiser().getAmount();
        this.originallyAmountDestroyer = shipPlacementPlayer.getDestroyer().getAmount();
        this.originallyAmountSubmarine = shipPlacementPlayer.getSubmarine().getAmount();
        
        createAmountShipLabelText();
        
        startPlacingShips(this.shipPlacementViewPlayer);
        startRemoveShip(this.shipPlacementViewPlayer);
        clickBackButton(this.shipPlacementViewPlayer, this.shipPlacementPlayer, this.shipPlacementEnemy, primaryStage);  
        readyToPlayPlayer();
 
        startPlacingShips(this.shipPlacementViewEnemy);
        startRemoveShip(this.shipPlacementViewEnemy);
        clickBackButton(this.shipPlacementViewEnemy, this.shipPlacementPlayer, this.shipPlacementEnemy, primaryStage);
        readyToPlayEnemy(); 
    }
    
    // Methoden Dreier, der das Setzen der Schiffe in 3 Schritten (3 verschiedene Buttons die gedr�ckt werden m�ssen) erm�glicht
    public void startPlacingShips(ShipPlacementView shipPlacementView) {
        for (Button button : shipPlacementView.getShipButtonList()) {
            button.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent event) {
                    // TODO Auto-generated method stub
                    if (gettingShipAmount(gettingCasket(button), shipPlacementView) > 0) {
                        secondStepOfPlacingShips(shipPlacementView, button);
                    } else {
                        new Alert(Alert.AlertType.WARNING, "Du hast keine Schiffe mehr von diesem Typ!", ButtonType.OK).show();
                    }
                }
            });
        }
    }
    
    public void secondStepOfPlacingShips(ShipPlacementView shipPlacementView, Button button) {
        for (Button buttonOne : shipPlacementView.getButtonList()) {
            buttonOne.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent event) {
                    placementActive = true;
                    // TODO Auto-generated method stub
                    if (checkLegalPlacement(buttonOne)) {
                        thirdStepOfPlacingShips(shipPlacementView, button, buttonOne);
                    } else {
                        new Alert(Alert.AlertType.WARNING, "Platzierung des Schiffes an dieser Stelle nicht m�glich!", ButtonType.OK).show();
                    }
                }
            });
        }     
    }

    public void thirdStepOfPlacingShips(ShipPlacementView shipPlacementView, Button button, Button buttonOne) {
        for (Button buttonTwo : shipPlacementView.getButtonList()) {
            buttonTwo.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent event) {
                    // TODO Auto-generated method stub
                    if (placementActive == true && checkLegalPlacementWholeShip(button, buttonOne, buttonTwo, shipPlacementView)) {
                        placeShip(button, buttonOne, buttonTwo, shipPlacementView);
                    } else {
                        new Alert(Alert.AlertType.WARNING, "Platzierung  nicht m�glich!", ButtonType.OK).show();
                    }
                    
                }
            });
        }
    }
    
    // Methode, die signalisiert, dass der Spieler bereit f�r die Schlacht ist, das 2D-Array f�llt und die Schiffplatzierungsansicht f�r den Gegner �ffnet
    public void readyToPlayPlayer() {
        this.shipPlacementViewPlayer.getStartTheBattleButton().setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                if (Integer.parseInt(shipPlacementViewPlayer.getAmountBattleshipLabel().getText()) == 0 &&
                        Integer.parseInt(shipPlacementViewPlayer.getAmountCruiserLabel().getText()) == 0 &&
                        Integer.parseInt(shipPlacementViewPlayer.getAmountDestroyerLabel().getText()) == 0 &&
                        Integer.parseInt(shipPlacementViewPlayer.getAmountSubmarineLabel().getText()) == 0) {
                    placementPlayer = fillPlayground(shipPlacementViewPlayer, shipPlacementPlayer, placementPlayer);
                    if (whichGameModus == 2) {
                        createShipPlacementViewEnemy();
                    } else {
                        autoPlaceShipPlacementEnemy(shipPlacementEnemy);
                    }
                } else {
                    new Alert(Alert.AlertType.WARNING, "Du hast noch Schiffe zu platzieren!", ButtonType.OK).show();
                }
            }
        });
    }
    
    // Methode, die signalisiert, dass der Gegner bereit f�r die Schlacht ist, das 2D-Array f�llt und die Spielfeldansicht �ffnet
    public void readyToPlayEnemy() {
        this.shipPlacementViewEnemy.getStartTheBattleButton().setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                if (Integer.parseInt(shipPlacementViewEnemy.getAmountBattleshipLabel().getText()) == 0 &&
                        Integer.parseInt(shipPlacementViewEnemy.getAmountCruiserLabel().getText()) == 0 &&
                        Integer.parseInt(shipPlacementViewEnemy.getAmountDestroyerLabel().getText()) == 0 &&
                        Integer.parseInt(shipPlacementViewEnemy.getAmountSubmarineLabel().getText()) == 0) {
                    placementEnemy = fillPlayground(shipPlacementViewEnemy, shipPlacementEnemy, placementEnemy);
                    new PlaygroundController(new Playground(placementPlayer, player, placementEnemy, enemy), primaryStage, originallyAmountBattleShips, originallyAmountCruiser, originallyAmountDestroyer, originallyAmountSubmarine);
                } else {
                    new Alert(Alert.AlertType.WARNING, "Du hast noch Schiffe zu platzieren!", ButtonType.OK).show();
                }
            } 
        });
    }
    
    // Methode, die automatisch die Schiffe des Gegners setzt, wenn dieser der "Computer" ist
    public void autoPlaceShipPlacementEnemy(ShipPlacement shipPlacementEnemy) {
        int amountBattleships = shipPlacementEnemy.getBattleship().getAmount();
        int amountCruiser = shipPlacementEnemy.getCruiser().getAmount();
        int amountDestroyer = shipPlacementEnemy.getDestroyer().getAmount();
        int amountSubmarine = shipPlacementEnemy.getSubmarine().getAmount();
        
        int playgroundWidth = shipPlacementEnemy.getWidth();
        int playgroundHeight = shipPlacementEnemy.getHeight();
        this.placementEnemy = new String[playgroundWidth][playgroundHeight];
        
        int randomShip;
        int randomPlaceX;
        int randomPlaceY;
        int randomDirection;
        boolean hasShips = false;
        boolean isSuccess = false;
        int counter = playgroundHeight*playgroundWidth*playgroundWidth;
        
        while (hasShips = hasShips(amountBattleships, amountCruiser, amountDestroyer, amountSubmarine)) { // jedesmal Pr�fung, ob noch Schiffe vorhanden sind
            isSuccess = false;
            while (!isSuccess) {
                randomPlaceX = (int) Math.floor(Math.random()*(playgroundWidth)); // Zahl kann nur von 0 bis zur Breite sein und liegt somit innerhalb des Array
                randomPlaceY = (int) Math.floor(Math.random()*(playgroundHeight)); // Zahl kann nur von 0 bis zur H�he sein und liegt somit innerhalb des Array
                randomDirection = (int) Math.floor(Math.random()*4)+1; // 1 = oben, 2 = rechts, 3 = unten, 4 = links Zahl kann nur zwischen 1 und 4 liegen
                randomShip = randomShip(amountBattleships, amountCruiser, amountDestroyer, amountSubmarine);
            
                if (checkMiniPlacement(randomPlaceX, randomPlaceY, this.placementEnemy)) { // Pr�fung, ob der Startpunkt zum Setzen des Schiffes im Array leer ist
                    if (checkPlacement(randomPlaceX, randomPlaceY, getCasketForAutoFill(randomShip), randomDirection, this.placementEnemy)) { // Pr�fung, ob das Array an den Stellen leer ist, wo das Schiff liegen soll
                        autoPlaceShips(randomPlaceX, randomPlaceY, getCasketForAutoFill(randomShip), randomDirection, this.placementEnemy); // setzen des Schiffes, wo vorher die Pr�fung stattfand
                        isSuccess = true; // Schiff wurde platziert :)
                        if (getCasketForAutoFill(randomShip) == 5) { // if fragt die Anzahl der K�stchen des RandomShip ab, um somit zu wissen, welche Variable runtergez�hlt werden muss
                            amountBattleships--;
                        } else if (getCasketForAutoFill(randomShip) == 4) {
                            amountCruiser--;
                        } else if (getCasketForAutoFill(randomShip) == 3) {
                            amountDestroyer--;
                        } else if (getCasketForAutoFill(randomShip) == 2) {
                            amountSubmarine--;
                        }
                    }
                } 
                counter--;
                if (counter == 0 && (hasShips = hasShips(amountBattleships, amountCruiser, amountDestroyer, amountSubmarine))) {
                    new Alert(Alert.AlertType.WARNING, "Sorry - Das hat zu lange gedauert. Bitte dr�cke erneut den Button 'Bereit f�r die Schlacht'.", ButtonType.OK).show();
                    return;
                }
            }   
        }
        if (!(hasShips = hasShips(amountBattleships, amountCruiser, amountDestroyer, amountSubmarine))) { // Wenn keine Schiffe mehr vorhanden sind, m�ssen sie alle gesetzt worden sein und das Array kann zuende gef�llt werden
            for (int i = 0; i < this.placementEnemy.length; i++) {
                for (int j = 0; j < this.placementEnemy[i].length; j++) {
                    if (this.placementEnemy[i][j] == null) {
                        this.placementEnemy[i][j] = "water";
                    }
                }
            }
            new PlaygroundController(new Playground(placementPlayer, player, placementEnemy, enemy), primaryStage, originallyAmountBattleShips, originallyAmountCruiser, originallyAmountDestroyer, originallyAmountSubmarine );  // Jetzt geht es in die PlayGroundView
        }
    }
    
    // Methode die einen Boolean zur�ckgibt, ob noch Schiffe zu setzen sind
    public Boolean hasShips(int amountBattleships, int amountCruiser, int amountDestroyer, int amountSubmarine) {
        Boolean hasShips = false;
        if (amountBattleships > 0 || amountCruiser > 0 || amountDestroyer > 0 || amountSubmarine > 0) {
            hasShips = true;
        }
        return hasShips;
    }
    
    // Methode, die pr�ft, ob der angegebene Platz im Array auch innerhalb des Arrays liegt und null, also frei ist
    public Boolean checkMiniPlacement(int randomX, int randomY, String[][] placement) {
        Boolean isFree = false;
        if (((randomX >= 0 && randomX < placement.length) && (randomY >= 0 && randomY < placement[randomX].length)) && placement[randomX][randomY] == null) {
            isFree = true;
        }
        return isFree;
    }
        
    // Methode, die Pr�ft, ob das Schiff platziert werden kann
    public Boolean checkPlacement(int randomX, int randomY, int casket, int randomDirection, String[][] placement) { //1 = oben, 2 = rechts, 3 = unten, 4 = links Zahl kann nur zwischen 1 und 4 liegen
        Boolean isFree = false;
        int x = randomX;
        int y = randomY;
        
            if (randomDirection == 1) {
                for (int i = 1; i < casket; i++) {
                    if (checkMiniPlacement(x, y-1, placement)) {
                        isFree = true;
                        y--;
                    } else {
                        isFree = false;
                        break;
                    }
                }
            } else if (randomDirection == 2) {
                for(int i = 1; i < casket; i++) {
                    if (checkMiniPlacement(x+1, y, placement)) {
                        isFree = true;
                        x++;
                    } else {
                        isFree = false;
                        break;
                    }
                }
            } else if (randomDirection == 3) {
                for (int i = 1; i < casket; i++) {
                    if (checkMiniPlacement(x, y+1, placement)) {
                        isFree = true; 
                        y++;
                    } else {
                        isFree = false;
                        break;
                    }
                }
            } else if (randomDirection == 4) {
                for (int i = 1; i < casket; i++) {
                    if (checkMiniPlacement(x-1, y, placement)) {
                        isFree = true; 
                        x--;
                    } else {
                        isFree = false;
                        break;
                    }
                }
            }
        return isFree;        
    }
    
    // Methode, die nach erfolgreicher "ist der Platzfrei?" Pr�fung, die Schiffe an die Stelle platziert
    public void autoPlaceShips(int randomX, int randomY, int casket, int randomDirection, String[][] placement) {
        int x = randomX;
        int y = randomY; 
        placement[x][y] = "ship";            
        
        for (int i = 1; i < casket; i++) { //1 = oben, 2 = rechts, 3 = unten, 4 = links - Zahl kann nur zwischen 1 und 4 liegen
            if (randomDirection == 1) {
                placement[x][y-i] = "ship";
            } else if (randomDirection == 2) {
                placement[x+i][y] = "ship";
            } else if (randomDirection == 3) {
                placement[x][y+i] = "ship";
            } else if (randomDirection == 4) {
                placement[x-i][y] = "ship";
            }
        }
        autoPlaceBlockedWater(randomX, randomY, casket, randomDirection, placement);
    }
    
    // Methode, die um die automatisch Platzierten Schiffe das Wasser setzt
    public void autoPlaceBlockedWater(int randomX, int randomY, int casket, int randomDirection, String[][] placement) {
        int x = randomX;
        int y = randomY;
       
        if (randomDirection == 2) { // rechts
            for (int i = -1; i < casket+1; i++) {
                if ((x+i >= 0 && y-1 >= 0) && (x+i < placement.length && y-1 < placement[x+i].length) && placement[x+i][y-1] == null) {
                    placement[x+i][y-1] = "water";
                }
                if ((x+i >= 0 && y+1 >= 0) && (x+i < placement.length && y+1 < placement[x+i].length) && placement[x+i][y+1] == null) {
                    placement[x+i][y+1] = "water";
                }
            }
            if ((x-1 >= 0 && y >= 0) && (x-1 < placement.length && y < placement[x-1].length) && placement[x-1][y] == null) {
                placement[x-1][y] = "water";
            }
            if ((x+casket >= 0 && y >= 0) && (x+casket < placement.length && y < placement[x+casket].length) && placement[x+casket][y] == null) {
                placement[x+casket][y] = "water";
            }
        }
        if (randomDirection == 4) { // links
            for (int i = 1; i > -(casket+1); i--) {
                if ((x+i >= 0 && y-1 >= 0) && (x+i < placement.length && y-1 < placement[x+i].length) && placement[x+i][y-1] == null) {
                    placement[x+i][y-1] = "water";
                }
                if ((x+i >= 0 && y+1 >= 0) && (x+i < placement.length && y+1 < placement[x+i].length) && placement[x+i][y+1] == null) {
                    placement[x+i][y+1] = "water";
                }  
            }
            if ((x+1 >= 0 && y >= 0) && (x+1 < placement.length && y < placement[x+1].length) && placement[x+1][y] == null) {
                placement[x+1][y] = "water";
            }
            
            if ((x-casket >= 0 && y >= 0) && (x-casket < placement.length && y < placement[x-casket].length) && placement[x-casket][y] == null) {
                placement[x-casket][y] = "water";
            }
        }
        if (randomDirection == 3) { // unten
            for (int i = -1; i < casket+1; i++) {
                if ((x+1 >= 0 && y+i >= 0) && (x+1 < placement.length && y+i < placement[x+1].length) && placement[x+1][y+i] == null) {
                    placement[x+1][y+i] = "water";
                }
                if ((x-1 >= 0 && y+i >= 0) && (x-1 < placement.length && y+i < placement[x-1].length) && placement[x-1][y+i] == null) {
                    placement[x-1][y+i] = "water";
                }
            }
            if ((x >= 0 && y-1 >= 0) && (x < placement.length && y-1 < placement[x].length) && placement[x][y-1] == null) {
                placement[x][y-1] = "water";
            }
            if ((x >= 0 && y+casket >= 0) && (x < placement.length && y+casket < placement[x].length) && placement[x][y+casket] == null) {
                placement[x][y+casket] = "water";
            }  
        }
        if (randomDirection == 1) { // oben
            for (int i = 1; i > -(casket+1); i--) {
                if ((x+1 >= 0 && y+i >= 0) && (x+1 < placement.length && y+i < placement[x+1].length) && placement[x+1][y+i] == null) {
                    placement[x+1][y+i] = "water";
                }
                if ((x-1 >= 0 && y+i >= 0) && (x-1 < placement.length && y+i < placement[x-1].length) && placement[x-1][y+i] == null) {
                    placement[x-1][y+i] = "water";
                }
            }
            if ((x >= 0 && y+1 >= 0) && (x < placement.length && y+1 < placement[x].length) && placement[x][y+1] == null) {
                placement[x][y+1] = "water";
            }
            if ((x >= 0 && y-casket >= 0) && (x < placement.length && y-casket < placement[x].length) && placement[x][y-casket] == null) {
                placement[x][y-casket] = "water";
            } 
        }
    }
    
    
    // Methode, die aufgrund der randomShip Nummer die Schiffsl�nge (Anzahl der K�stchen) zur�ckgibt
    public int getCasketForAutoFill(int number) {
        int casket = 0;
        
        if (number == 1) { // Battleship
            casket = 5;
        } else if (number == 2) { // Cruiser
            casket = 4;
        } else if (number == 3) { // Destroyer
            casket = 3;
        } else if (number == 4) { // Submarine
            casket = 2;
        }
        return casket;
    }
    
    // Methode, die eine zuf�llige Zahl zur�ckgibt, wenn es noch gen�gend Schiffe der ausgew�hlten Sorte gibt
    public int randomShip(int amountBattleships, int amountCruiser, int amountDestroyer, int amountSubmarine) {
        int result = 0;
        int currentResult = (int) Math.floor(Math.random()*4) +1; // Zahl kann nur zwischen 1 und 4 liegen
        
        if (currentResult == 1 && amountBattleships > 0) {
            result = currentResult;
        } else if (currentResult == 2 && amountCruiser > 0) {
            result = currentResult;
        } else if (currentResult == 3 && amountDestroyer > 0) {
            result = currentResult;
        } else if (currentResult == 4 && amountSubmarine > 0) {
            result = currentResult;
        } else if (amountBattleships > 0 || amountCruiser > 0 || amountDestroyer > 0 || amountSubmarine > 0) {
            randomShip(amountBattleships, amountCruiser, amountDestroyer, amountSubmarine);
        }
        return result;
    }
    
    // Methode, die die Ansicht zum Platzieren der Schiffe f�r den Spieler erstellt
    public void createShipPlacementViewPlayer() {
        shipPlacementViewPlayer.createShipPlacementView(this.primaryStage);
    }
    
    // Methode, die die Ansicht zum Platzieren der Schiffe f�r den Gegner erstellt
    public void createShipPlacementViewEnemy() {
        shipPlacementViewEnemy.createShipPlacementView(this.primaryStage);
    }
    
    // Methode, die anhand der Buttonfarbe in der GridPane ein 2D-Array mit "Wasser" und "Schiff" f�llt
    public String[][] fillPlayground(ShipPlacementView shipPlacementView, ShipPlacement shipPlacement, String[][] placement) {
        placement = new String[shipPlacement.getWidth()][shipPlacement.getHeight()];
        GridPane playerGridPane = new GridPane();
        Button button = new Button();
        playerGridPane = shipPlacementView.getBattleFieldGridPane();
        
        for (int i = 0; i < shipPlacement.getWidth(); i++) {
            for (int j = 0; j < shipPlacement.getHeight(); j++) {
                button = (Button) getNodeFromGridPane(j, i, playerGridPane);
                if (button.getStyle().equals("-fx-background-color: #00FF00")) {
                    placement[i][j] = "ship";
                } else {
                    placement[i][j] = "water";
                }
            }      
        }
        return placement;
    }
    
    // Methode die pr�ft, ob der ausgew�hlte Button des zu setzenden Schiffes g�ltig ist
    public Boolean checkLegalPlacement(Node currentPlace) {
        if (currentPlace != null && currentPlace.getStyle() == "") {
            return true;
        }
        return false;
    }
    
    // Methode, die checkt, ob das Schiff an den gew�hltzen Platz gesetzt werden kann, wenn nicht, gibt es einen Alert
    public Boolean checkLegalPlacementWholeShip(Button shipType, Button startPlace, Button direction, ShipPlacementView shipPlacementView) {
        Boolean isLegal = false;
        int x1 = GridPane.getColumnIndex(startPlace);
        int y1 = GridPane.getRowIndex(startPlace);
        int x2 = GridPane.getColumnIndex(direction);
        int y2 = GridPane.getRowIndex(direction);
        int casket = gettingCasket(shipType);
        int currentX = x2;
        int currentY = y2;
        
        if (((x2-1 == x1) && y2 == y1) || ((x2+1 == x1) && y2 == y1) || (x2 == x1 && (y2+1 == y1)) || (x2 == x1 && (y2-1 == y1))) {
            if (casket == 2) {
                if (checkLegalPlacement(startPlace) && checkLegalPlacement(direction)) {
                    isLegal = true;
                } else {
                    isLegal = false;
                    new Alert(Alert.AlertType.WARNING, "Hier ist nicht genug Platz f�r dein Schiff.", ButtonType.OK).show();
                }
            } else if (x2 > x1 && y2 == y1) {
                for (int i = 2; i < casket; i++) {
                    if (checkLegalPlacement(getNodeFromGridPane(y2, currentX+1, shipPlacementView.getBattleFieldGridPane()))) {
                        isLegal = true;
                        currentX++;
                    } else {
                        isLegal = false;
                        new Alert(Alert.AlertType.WARNING, "Hier ist nicht genug Platz f�r dein Schiff.", ButtonType.OK).show();
                        break;
                    }
                }
            } else if (x2 < x1 && y2 == y1) {
                for (int i = 2; i < casket; i++) {
                    if (checkLegalPlacement(getNodeFromGridPane(y2, currentX-1, shipPlacementView.getBattleFieldGridPane()))) {
                        isLegal = true;
                        currentX--;
                    } else {
                        isLegal = false;
                        new Alert(Alert.AlertType.WARNING, "Hier ist nicht genug Platz f�r dein Schiff.", ButtonType.OK).show();
                        break;
                    }
                }
            } else if (y2 > y1 && x2 == x1) {
                for (int i = 2; i < casket; i++) {
                    if (checkLegalPlacement(getNodeFromGridPane(currentY+1, x2, shipPlacementView.getBattleFieldGridPane()))) {
                        isLegal = true;
                        currentY++;
                    } else {
                        isLegal = false;
                        new Alert(Alert.AlertType.WARNING, "Hier ist nicht genug Platz f�r dein Schiff.", ButtonType.OK).show();
                        break;
                    }
                }
            } else if (y2 < y1 && x2 == x1) {
                for (int i = 2; i < casket; i++) {
                    if (checkLegalPlacement(getNodeFromGridPane(currentY-1, x2, shipPlacementView.getBattleFieldGridPane()))) {
                        isLegal = true;
                        currentY--;
                    } else {
                        isLegal = false;
                        new Alert(Alert.AlertType.WARNING, "Hier ist nicht genug Platz f�r dein Schiff.", ButtonType.OK).show();
                        break;
                    }
                }
            }
        } else {
            new Alert(Alert.AlertType.WARNING, "Um die Richtung zu w�hlen, dr�cke das Feld direkt neben dem Startpunkt in der gew�nschten Richtung!", ButtonType.OK).show();
        }
        return isLegal;
    }
    
    // Methode setzt um ein platziertes Schiff herum Wasser, sodass die Platzierungsregeln eingehalten werden
    public void placeBlockedWater(Button shipType, Button startPlace, Button direction, ShipPlacementView shipPlacementView) {
        int x1 = GridPane.getColumnIndex(startPlace);
        int y1 = GridPane.getRowIndex(startPlace);
        int x2 = GridPane.getColumnIndex(direction);
        int y2 = GridPane.getRowIndex(direction);
        int casket = gettingCasket(shipType);
        
        if (x2 > x1 && y2 == y1) {
            for (int i = -1; i < casket+1; i++) {
                if (getNodeFromGridPane(y1-1, x1+i, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1-1, x1+i, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                    getNodeFromGridPane(y1-1, x1+i, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
                }
                if (getNodeFromGridPane(y1+1, x1+i, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1+1, x1+i, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                    getNodeFromGridPane(y1+1, x1+i, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF"); 
                }
            }
            if (getNodeFromGridPane(y1, x1-1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1, x1-1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                getNodeFromGridPane(y1, x1-1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            }
            if (getNodeFromGridPane(y1, x1+casket, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1, x1+casket, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                getNodeFromGridPane(y1, x1+casket, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            }
        }
        
        if (x2 < x1 && y2 == y1) {
            for (int i = 1; i > -(casket+1); i--) {
                if (getNodeFromGridPane(y1-1, x1+i, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1-1, x1+i, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                    getNodeFromGridPane(y1-1, x1+i, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
                }
                if (getNodeFromGridPane(y1+1, x1+i, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1+1, x1+i, shipPlacementView.getBattleFieldGridPane()).getStyle() == "" ) {
                    getNodeFromGridPane(y1+1, x1+i, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF"); 
                }
            } 
            if (getNodeFromGridPane(y1, x1+1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1, x1+1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                getNodeFromGridPane(y1, x1+1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            }
            if (getNodeFromGridPane(y1, x1-casket, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1, x1-casket, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                getNodeFromGridPane(y1, x1-casket, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            }
        }
        
        if (y2 > y1 && x2 == x1) {
            for (int i = -1; i < casket+1; i++) {
                if (getNodeFromGridPane(y1+i, x1+1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1+i, x1+1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                    getNodeFromGridPane(y1+i, x1+1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
                }
                if (getNodeFromGridPane(y1+i, x1-1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1+i, x1-1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                    getNodeFromGridPane(y1+i, x1-1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF"); 
                }
            }
            if (getNodeFromGridPane(y1-1, x1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1-1, x1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                getNodeFromGridPane(y1-1, x1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            }
            if (getNodeFromGridPane(y1+casket, x1, shipPlacementView.getBattleFieldGridPane()) != null &&  getNodeFromGridPane(y1+casket, x1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                getNodeFromGridPane(y1+casket, x1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            }
                
        }
        
        if (y2 < y1 && x2 == x1) {
            for (int i = 1; i > -(casket+1); i--) {
                if ( getNodeFromGridPane(y1+i, x1+1, shipPlacementView.getBattleFieldGridPane()) != null &&  getNodeFromGridPane(y1+i, x1+1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                    getNodeFromGridPane(y1+i, x1+1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
                }
                if (getNodeFromGridPane(y1+i, x1-1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1+i, x1-1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                    getNodeFromGridPane(y1+i, x1-1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF"); 
                }
            }
            if ( getNodeFromGridPane(y1+1, x1, shipPlacementView.getBattleFieldGridPane()) != null &&  getNodeFromGridPane(y1+1, x1, shipPlacementView.getBattleFieldGridPane()).getStyle() == "") {
                getNodeFromGridPane(y1+1, x1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            }
            if (getNodeFromGridPane(y1-casket, x1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y1-casket, x1, shipPlacementView.getBattleFieldGridPane()).getStyle() =="") {
                getNodeFromGridPane(y1-casket, x1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #0000FF");
            } 
        }
    }
   
    // Methode die das Entfernen von Schiffen einleitet und die Methoden b�ndelt
    public void startRemoveShip(ShipPlacementView shipPlacementView) {
        shipPlacementView.getDeleteButton().setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                for (Button button : shipPlacementView.getButtonList()) {
                    button.setOnAction(new EventHandler<ActionEvent>() {
                        
                        @Override
                        public void handle(ActionEvent arg0) {
                            if (button.getStyle().equals("-fx-background-color: #00FF00")) {
                                int shipCasket = searchAndDeleteNeighborsAndMySelf(button, shipPlacementView);
                                countingShips(gettingShipType(shipCasket), (-1), shipPlacementView);
                            } else {
                                new Alert(Alert.AlertType.WARNING, "Das ist kein Schiff!", ButtonType.OK).show();
                            }
                        }
                    });
                } 
            }  
        });
    }
    
    // Methode, die die gesetzten Schiffe wieder von der GridPane entfernt. Es ist dabei egal, welchen gr�nen Button von dem zu entfernenden Schiff man anklickt.
    // Methode entfernt nicht nur das Schiff, sondern gibt die Anzahl der K�stchen zur�ck, anhand dessen man den Schiffstype bestimmen kann
    public Integer searchAndDeleteNeighborsAndMySelf(Button button, ShipPlacementView shipPlacementView) {
        int x = GridPane.getColumnIndex(button);
        int y = GridPane.getRowIndex(button);
        int currentX = x;
        int currentY = y;
        int shipCasket;
        int counter = 0;
        
        button.setStyle("");
        removeBlockedWater(button, shipPlacementView);
        counter++;
    
        while (getNodeFromGridPane(y, currentX+1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y, currentX+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")) {
            getNodeFromGridPane(y, currentX+1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
            removeBlockedWater(getNodeFromGridPane(y, currentX+1, shipPlacementView.getBattleFieldGridPane()), shipPlacementView);
            currentX++;
            counter++;
        }
        
        currentX = x;
        
        while (getNodeFromGridPane(y, currentX-1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y, currentX-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")) {
            getNodeFromGridPane(y, currentX-1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
            removeBlockedWater(getNodeFromGridPane(y, currentX-1, shipPlacementView.getBattleFieldGridPane()), shipPlacementView);
            currentX--;
            counter++;
        }
        while(getNodeFromGridPane(currentY+1, x, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(currentY+1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")) {
            getNodeFromGridPane(currentY+1, x, shipPlacementView.getBattleFieldGridPane()).setStyle("");
            removeBlockedWater(getNodeFromGridPane(currentY+1, x, shipPlacementView.getBattleFieldGridPane()), shipPlacementView);
            currentY++;
            counter++;
        }
        
        currentY = y;
        
        while (getNodeFromGridPane(currentY-1, x, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(currentY-1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")) {
            getNodeFromGridPane(currentY-1, x, shipPlacementView.getBattleFieldGridPane()).setStyle("");
            removeBlockedWater(getNodeFromGridPane(currentY-1, x, shipPlacementView.getBattleFieldGridPane()), shipPlacementView);
            currentY--;
            counter++;
        }
        
        shipCasket = counter;
        return shipCasket;
    }
      
    // Methode z�hlt die Anzahl der Schiffe hoch und runter, um zu sehen, wieviele Schiffe eines Typs noch gesetzt werden k�nnen
    public void countingShips(String shipType, int upOrDown, ShipPlacementView shipPlacementView) {
        int currentAmount = 0;
        
        switch (shipType) {
        case "Schlachtschiff":
            currentAmount = Integer.parseInt(shipPlacementView.getAmountBattleshipLabel().getText());
            shipPlacementView.getAmountBattleshipLabel().setText(String.valueOf(currentAmount - upOrDown));
            break;
        case "Kreuzer":
            currentAmount = Integer.parseInt(shipPlacementView.getAmountCruiserLabel().getText());
            shipPlacementView.getAmountCruiserLabel().setText(String.valueOf(currentAmount - upOrDown));
            break;
        case "Zerst�rer":
            currentAmount = Integer.parseInt(shipPlacementView.getAmountDestroyerLabel().getText());
            shipPlacementView.getAmountDestroyerLabel().setText(String.valueOf(currentAmount - upOrDown));
            break;
        case "U-Boot":
            currentAmount = Integer.parseInt(shipPlacementView.getAmountSubmarineLabel().getText());
            shipPlacementView.getAmountSubmarineLabel().setText(String.valueOf(currentAmount - upOrDown));
            break;
        }   
    }
    
    // Methode, die aufgrund folgender Matrix pr�ft, ob es angrenzend einen Wasser-Button gibt und an dessen angrenzenden Stellen sich ein anderes Schiff befindet und das Wasser nicht entfernt werden kann
    /*
     * Matrix: (0 ist der �bergebene Button des zu l�schenden Schiffes)
     * 20   /   21  /   22  /   23  /   24
     * 19   /   6   /   7   /   8   /   9
     * 18   /   5   /   0   /   1   /   10
     * 17   /   4   /   3   /   2   /   11
     * 16   /   15  /   14  /   13  /   12
     */
    public void removeBlockedWater(Node button, ShipPlacementView shipPlacementView) {
        int x = GridPane.getColumnIndex(button);
        int y = GridPane.getRowIndex(button);
        // Erster Fall
        if ((getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*8*/           (getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*9*/           (getNodeFromGridPane(y-1, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*10*/          (getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*11*/          (getNodeFromGridPane(y+1, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*2*/           (getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
        // Zweiter Fall
        if ((getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*1*/           (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*10*/          (getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*11*/          (getNodeFromGridPane(y+1, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*12*/          (getNodeFromGridPane(y+2, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*13*/          (getNodeFromGridPane(y+2, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*14*/          (getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*3*/           (getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
        // Dritter Fall
        if ((getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*1*/           (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*2*/           (getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*13*/          (getNodeFromGridPane(y+2, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*14*/          (getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*15*/          (getNodeFromGridPane(y+2, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*4*/           (getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*5*/           (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
        // Vierter Fall
        if ((getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*3*/           (getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*14*/          (getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*15*/          (getNodeFromGridPane(y+2, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*16*/          (getNodeFromGridPane(y+2, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+2, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+2, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*17*/          (getNodeFromGridPane(y+1, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*18*/          (getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*5*/           (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
        // F�nfter Fall
        if ((getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*3*/           (getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*4*/           (getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*17*/          (getNodeFromGridPane(y+1, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y+1, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y+1, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*18*/          (getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*19*/          (getNodeFromGridPane(y-1, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*6*/           (getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*7*/           (getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
        // Sechster Fall
        if ((getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*5*/           (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*18*/          (getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*19*/          (getNodeFromGridPane(y-1, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*20*/          (getNodeFromGridPane(y-2, x-2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x-2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x-2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*21*/          (getNodeFromGridPane(y-2, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*22*/          (getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*7*/           (getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
        // Siebter Fall
        if ((getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*5*/           (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*6*/           (getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*21*/          (getNodeFromGridPane(y-2, x-1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x-1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x-1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*22*/          (getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*23*/          (getNodeFromGridPane(y-2, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*8*/           (getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*1*/           (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
        // Achter Fall
        if ((getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()) != null && getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #0000FF")) &&
/*7*/           (getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*22*/          (getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*23*/          (getNodeFromGridPane(y-2, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*24*/          (getNodeFromGridPane(y-2, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-2, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-2, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*9*/           (getNodeFromGridPane(y-1, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y-1, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y-1, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*10*/          (getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x+2, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00"))) &&
/*1*/           (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) == null || (getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()) != null && !getNodeFromGridPane(y, x+1, shipPlacementView.getBattleFieldGridPane()).getStyle().equals("-fx-background-color: #00FF00")))) {
            
            getNodeFromGridPane(y-1, x+1, shipPlacementView.getBattleFieldGridPane()).setStyle("");
        }
    }
    
    // Methode setzt die Schiffe auf der GridPane in dem es die Buttons gr�n f�rbt
    public void placeShip(Button shipType, Button startPlace, Button direction, ShipPlacementView shipPlacementView) { 
        placementActive = false;
        int x1 = GridPane.getColumnIndex(startPlace);
        int y1 = GridPane.getRowIndex(startPlace);
        int x2 = GridPane.getColumnIndex(direction);
        int y2 = GridPane.getRowIndex(direction);
        int casket = gettingCasket(shipType);
        int currentX = x2;
        int currentY = y2;
               
        if ((x2 == (x1+1) && y2 == y1) || (x2 == (x1-1) && y2 == y1) || (y2 == (y1+1) && x2 == x1) || (y2 == (y1-1) && x2 == x1)) {
            startPlace.setStyle("-fx-background-color: #00FF00"); 
            direction.setStyle("-fx-background-color: #00FF00");
                   
            if (x2 > x1 && y2 == y1) {
                for (int i = 2; i < casket; i++) {
                    getNodeFromGridPane(y2, currentX+1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #00FF00");
                    currentX++;
                }
            } else if (x2 < x1 && y2 == y1) {
                for (int i = 2; i < casket; i++) {
                    getNodeFromGridPane(y2, currentX-1, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #00FF00");
                    currentX--;
                }
            } else if (y2 > y1 && x2 == x1) {
                for (int i = 2; i < casket; i++) {
                    getNodeFromGridPane(currentY+1, x2, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #00FF00");
                    currentY++;
                }
            } else if (y2 < y1 && x2 == x1) {
                for (int i = 2; i < casket; i++) {
                    getNodeFromGridPane(currentY-1, x2, shipPlacementView.getBattleFieldGridPane()).setStyle("-fx-background-color: #00FF00");
                    currentY--;
                }
            }
            placeBlockedWater(shipType, startPlace, direction, shipPlacementView);
            countingShips(shipType.getText(), 1, shipPlacementView);        
        }
    }
    
    
    // Methode, die einem den Node der GridPane an den gesuchten Korrdinaten zur�ckgibt
    public Node getNodeFromGridPane(int row, int column, GridPane battleFieldGridPane) {
        Node wantToHave = null;
        ObservableList<Node> gridPaneChildren = battleFieldGridPane.getChildren();
        
        for (Node node : gridPaneChildren) {
            if (GridPane.getRowIndex(node) == row && GridPane.getColumnIndex(node) == column) {
                wantToHave = node;
                break;
            }
        }
        return wantToHave;
    }
    
    // Methode die initial die Anzahl der zu setzenden Schiffe in die Labels der View schreibt. Die Werte werden aus der StartView mit dem ShipPlacement �bergeben.
    public void createAmountShipLabelText() {
        this.shipPlacementViewPlayer.getAmountBattleshipLabel().setText(String.valueOf(this.shipPlacementPlayer.getBattleship().getAmount()));
        this.shipPlacementViewPlayer.getAmountCruiserLabel().setText(String.valueOf(this.shipPlacementPlayer.getCruiser().getAmount()));
        this.shipPlacementViewPlayer.getAmountDestroyerLabel().setText(String.valueOf(this.shipPlacementPlayer.getDestroyer().getAmount()));
        this.shipPlacementViewPlayer.getAmountSubmarineLabel().setText(String.valueOf(this.shipPlacementPlayer.getSubmarine().getAmount()));
        
        this.shipPlacementViewEnemy.getAmountBattleshipLabel().setText(String.valueOf(this.shipPlacementEnemy.getBattleship().getAmount()));
        this.shipPlacementViewEnemy.getAmountCruiserLabel().setText(String.valueOf(this.shipPlacementEnemy.getCruiser().getAmount()));
        this.shipPlacementViewEnemy.getAmountDestroyerLabel().setText(String.valueOf(this.shipPlacementEnemy.getDestroyer().getAmount()));
        this.shipPlacementViewEnemy.getAmountSubmarineLabel().setText(String.valueOf(this.shipPlacementEnemy.getSubmarine().getAmount()));
    }
    
    // Methode, die anhand des �bergebenen "shipType"-Buttons, die Anzahl der zu setzenden K�stchen je Schiffsart zur�ckgibt
    public int gettingCasket(Button shipType) {
        int casket = 0;
        
        switch (shipType.getText()) {
        case "Schlachtschiff":
            casket = 5;
            break;
        case "Kreuzer":
            casket = 4;
            break;
        case "Zerst�rer":
            casket = 3;
            break;
        case "U-Boot":
            casket = 2;
            break;
        }
        return casket;
    }
    
 // Methode, die anhand des �bergebenen K�stchenanzahl, die Schiffsart zur�ckgibt
    public String gettingShipType(int casket) {
        String shipType = "";
        
        switch (casket) {
        case 5:
            shipType = "Schlachtschiff";
            break;
        case 4:
            shipType = "Kreuzer";
            break;
        case 3:
            shipType = "Zerst�rer";
            break;
        case 2:
            shipType = "U-Boot";
            break;
        }
        return shipType;
    }
    
    // Methode, die anhand der �bergebenen ShipPlacementView, die Anzahl der noch vorhandenen Schiffe je Schiffsart zur�ckgibt
    public int gettingShipAmount(int casket, ShipPlacementView shipPlacementView) {
        int amount = 0;
        
        switch (casket) {
        case 2:
            amount = Integer.parseInt(shipPlacementView.getAmountSubmarineLabel().getText());
            break;
        case 3:
            amount = Integer.parseInt(shipPlacementView.getAmountDestroyerLabel().getText());
            break;
        case 4:
            amount = Integer.parseInt(shipPlacementView.getAmountCruiserLabel().getText());
            break;
        case 5:
            amount = Integer.parseInt(shipPlacementView.getAmountBattleshipLabel().getText());
            break;
        }
        return amount;
    }
    
    // Methode, die eine Ansicht zur�ckspringt, also in die StartView, wenn man den Zur�ck-Button dr�ckt
    public void clickBackButton(ShipPlacementView shipPlacementViewNow, ShipPlacement shipPlacementPlayer, ShipPlacement shipPlacementEnemy, Stage primaryStage) {
        shipPlacementViewNow.getBackButton().setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                changeSceneBack(shipPlacementPlayer, shipPlacementEnemy, primaryStage);
            }
        });
    }
    
    // Methode, die beim Anklicken des Zur�ck-Buttons wieder in die StartView wechselt, die gemachten Eingaben aber �bernimmt
    public void changeSceneBack(ShipPlacement shipPlacementPlayer, ShipPlacement shipPlacementEnemy, Stage primaryStage) {  
        StartView startView = new StartView();
        startView.getAmountBattleshipsField().setText(String.valueOf(shipPlacementPlayer.getBattleship().getAmount()));
        startView.getAmountCruiserField().setText(String.valueOf(shipPlacementPlayer.getCruiser().getAmount()));
        startView.getAmountDestroyerField().setText(String.valueOf(shipPlacementPlayer.getDestroyer().getAmount()));
        startView.getAmountSubmarineField().setText(String.valueOf(shipPlacementPlayer.getSubmarine().getAmount()));
        startView.getNamePlayerOneField().setText(shipPlacementPlayer.getPlayer().getName());
        
        if (!shipPlacementEnemy.getPlayer().getName().equals("Computer")) {
            startView.getNamePlayerTwoField().setText(shipPlacementEnemy.getPlayer().getName());
        }
        
        StartViewController startViewController = new StartViewController(startView);
        primaryStage.setScene(startViewController.start(primaryStage));
    }

}

