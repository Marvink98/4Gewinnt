package de.volkswagen.controller;

import java.util.ArrayList;
import java.util.List;

import de.volkswagen.database.DBUtils;
import de.volkswagen.model.Player;
import de.volkswagen.model.Playground;
import de.volkswagen.threads.TotalTimeThread;
import de.volkswagen.view.PlaygroundView;
import de.volkswagen.view.StartView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class PlaygroundController {

	private Playground playground;
	private PlaygroundView playgroundView;
	private Stage primaryStage;
	private List<String> tileCounter;
	private boolean intermediate;
	private boolean playersTurn;
	private String aILastHit;
	private boolean aIVerticalShip;
	private boolean aIHorizontalShip;

	public PlaygroundController(Playground playground, Stage primaryStage, int originallyBattleships,
			int originallyCruiser, int originallyDestroyer, int originallySubmarine) {
		this.aILastHit = "none";
		this.aIVerticalShip = true;
		this.aIHorizontalShip = true;
		this.tileCounter = new ArrayList<String>();
		this.playground = playground;
		this.intermediate = false;
		this.playersTurn = true;
		this.playgroundView = new PlaygroundView();
		this.playgroundView	.getPlayerBattleshipAmountLabel()
							.setText(String.valueOf(originallyBattleships));
		this.playgroundView	.getPlayerCruiserAmountLabel()
							.setText(String.valueOf(originallyCruiser));
		this.playgroundView	.getPlayerDestroyerAmountLabel()
							.setText(String.valueOf(originallyDestroyer));
		this.playgroundView	.getPlayerSubmarineAmountLabel()
							.setText(String.valueOf(originallySubmarine));
		this.playgroundView	.getEnemyBattleshipAmountLabel()
							.setText(String.valueOf(originallyBattleships));
		this.playgroundView	.getEnemyCruiserAmountLabel()
							.setText(String.valueOf(originallyCruiser));
		this.playgroundView	.getEnemyDestroyerAmountLabel()
							.setText(String.valueOf(originallyDestroyer));
		this.playgroundView	.getEnemySubmarineAmountLabel()
							.setText(String.valueOf(originallySubmarine));
		this.primaryStage = primaryStage;
		primaryStage.setScene(playgroundView.createPlaygroundViewWithLegend(this.playground.getPlacementPlayer(),
				this.playground.getPlacementEnemy()));
		addButtonFunctionsInit();

		// playingTime();
	}

	// Gibt allen Buttons im Playground ihre Funktion am Anfang
	private void addButtonFunctionsInit() {
		this.playgroundView	.getQuitButton()
							.setOnAction(new EventHandler<ActionEvent>() {
								public void handle(ActionEvent event) {
									primaryStage.close();
								}
							});

		this.playgroundView	.getFinalPlayground()
							.setOnKeyPressed(new EventHandler<KeyEvent>() {

								@Override
								public void handle(KeyEvent event) {
									if (intermediate) {
										if (event	.getCode()
													.equals(KeyCode.ENTER)) {
											if (playersTurn) {
												playgroundView.createPlaygroundViewWithLegend(
														playground.getPlacementPlayer(),
														playground.getPlacementEnemy());
												addButtonFunctionsPlayerTurn();
												intermediate = false;
											} else {
												playgroundView.createPlaygroundViewWithLegendMirrored(
														playground.getPlacementPlayer(),
														playground.getPlacementEnemy());
												addButtonFunctionsEnemyTurn();
												intermediate = false;
											}
										}
									}
								}
							});
		addButtonFunctionsPlayerTurn();

	}

	private void addButtonFunctionsPlayerTurn() {
		for (Node node : this.playgroundView.getEnemyGridPane()
											.getChildren()) {
			enemyPlaygroundButtonsFunction((Button) node);
		}
	}

	private void addButtonFunctionsEnemyTurn() {
		for (Node node : this.playgroundView.getEnemyGridPane()
											.getChildren()) {
			playerPlaygroundButtonsFunction((Button) node);
		}
	}

	// Gibt einem Button auf dem Player FIeld seine Funktion
	private void playerPlaygroundButtonsFunction(Button button) {
		button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				shootPlayer(getRowIndexOfButton((Button) event.getSource()),
						getColumnIndexOfButton((Button) event.getSource()));
			}
		});
	}

	// Gibt einem Button auf dem Enemy Field seine Funktion
	private void enemyPlaygroundButtonsFunction(Button button) {
		button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				shootEnemy(getRowIndexOfButton((Button) event.getSource()),
						getColumnIndexOfButton((Button) event.getSource()));
			}
		});
	}

	public void sinkShipEnemy(int columnIndex, int rowIndex) {
		if (this.playground.getPlacementEnemy()[rowIndex][columnIndex] == "hit") {
			getNodeFromCoordinate(playgroundView.getEnemyGridPane(), columnIndex, rowIndex).setStyle(
					"-fx-background-color: #FF0000");
			this.playground.getPlacementEnemy()[rowIndex][columnIndex] = "sunk";
			if (rowIndex != this.playground.getPlacementEnemy().length - 1) {
				sinkShipEnemy(columnIndex, rowIndex + 1);
			}
			if (columnIndex != this.playground.getPlacementEnemy()[rowIndex].length - 1) {
				sinkShipEnemy(columnIndex + 1, rowIndex);
			}
			if (rowIndex != 0) {
				sinkShipEnemy(columnIndex, rowIndex - 1);
			}
			if (columnIndex != 0) {
				sinkShipEnemy(columnIndex - 1, rowIndex);
			}
		}
	}

	public void sinkShipPlayer(int columnIndex, int rowIndex) {
		if (this.playground.getPlacementPlayer()[rowIndex][columnIndex] == "hit") {
			getNodeFromCoordinate(playgroundView.getPlayerGridPane(), columnIndex, rowIndex).setStyle(
					"-fx-background-color: #FF0000");
			this.playground.getPlacementPlayer()[rowIndex][columnIndex] = "sunk";
			if (rowIndex != this.playground.getPlacementPlayer().length - 1) {
				sinkShipPlayer(columnIndex, rowIndex + 1);
			}
			if (columnIndex != this.playground.getPlacementPlayer()[rowIndex].length - 1) {
				sinkShipPlayer(columnIndex + 1, rowIndex);
			}
			if (rowIndex != 0) {
				sinkShipPlayer(columnIndex, rowIndex - 1);
			}
			if (columnIndex != 0) {
				sinkShipPlayer(columnIndex - 1, rowIndex);
			}
		}

	}

	// �berpr�ft, ob ein Treffer ein Schiff zerst�rt hat oder nicht, aber nur beim
	// Gegner
	public void checkShipSunkEnemy(int columnIndex, int rowIndex) {
		this.tileCounter.clear();
		if (this.playground.getPlacementEnemy()[rowIndex][columnIndex] == "hit") {
			tileCounter.add("hit");
			if (rowIndex != this.playground.getPlacementEnemy().length - 1) {
				checkNextShipTileEnemy(rowIndex + 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != this.playground.getPlacementEnemy()[rowIndex].length - 1) {
				checkNextShipTileEnemy(rowIndex, columnIndex + 1, rowIndex, columnIndex);
			}
			if (rowIndex != 0) {
				checkNextShipTileEnemy(rowIndex - 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != 0) {
				checkNextShipTileEnemy(rowIndex, columnIndex - 1, rowIndex, columnIndex);
			}

			if (!this.tileCounter.contains("ship not sunk")) {
				sinkShipEnemy(columnIndex, rowIndex);
				switch (this.tileCounter.size()) {
				case 2:
					sendHitMessage(playground	.getPlayer()
												.getName()
							+ " hat ein U-Bott versenkt");
					updateScore(10, this.playground.getPlayer());
					this.playgroundView.setEnemySubmarineAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getEnemySubmarineAmountLabel()
																				.getText()))
									- 1));
					break;
				case 3:
					sendHitMessage(playground	.getPlayer()
												.getName()
							+ " hat einen Zerst�rer versenkt");
					updateScore(12, this.playground.getPlayer());
					this.playgroundView.setEnemyDestroyerAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getEnemyDestroyerAmountLabel()
																				.getText()))
									- 1));
					break;
				case 4:
					sendHitMessage(playground	.getPlayer()
												.getName()
							+ " hat einen Kreuzer versenkt");
					updateScore(15, this.playground.getPlayer());
					this.playgroundView.setEnemyCruiserAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getEnemyCruiserAmountLabel()
																				.getText()))
									- 1));
					break;
				case 5:
					sendHitMessage(playground	.getPlayer()
												.getName()
							+ " hat ein Schlachtschiff versenkt");
					updateScore(20, this.playground.getPlayer());
					this.playgroundView.setEnemyBattleshipAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getEnemyBattleshipAmountLabel()
																				.getText()))
									- 1));
					break;
				default:
					System.out.println("default erreicht");
					break;
				}
			}
		}
	}

	// �berpr�ft, ob ein Treffer ein Schiff zerst�rt hat oder nicht, aber nur beim
	// Spieler
	public void checkShipSunkPlayer(int columnIndex, int rowIndex) {
		this.tileCounter.clear();
		if (this.playground.getPlacementPlayer()[rowIndex][columnIndex] == "hit") {
			tileCounter.add("hit");
			if (rowIndex != this.playground.getPlacementPlayer().length - 1) {
				checkNextShipTilePlayer(rowIndex + 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != this.playground.getPlacementPlayer()[rowIndex].length - 1) {
				checkNextShipTilePlayer(rowIndex, columnIndex + 1, rowIndex, columnIndex);
			}
			if (rowIndex != 0) {
				checkNextShipTilePlayer(rowIndex - 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != 0) {
				checkNextShipTilePlayer(rowIndex, columnIndex - 1, rowIndex, columnIndex);
			}
			if (!this.tileCounter.contains("ship not sunk")) {
				sinkShipPlayer(columnIndex, rowIndex);

				int casket = 0;
				switch (this.tileCounter.size()) {
				case 2:
					sendHitMessage(playground	.getEnemy()
												.getName()
							+ " hat ein U-Bott versenkt");
					updateScore(10, this.playground.getEnemy());
					casket = 2;
					this.playgroundView.setPlayerSubmarineAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getPlayerSubmarineAmountLabel()
																				.getText()))
									- 1));
					break;
				case 3:
					sendHitMessage(playground	.getEnemy()
												.getName()
							+ " hat einen Zerst�rer versenkt");
					updateScore(12, this.playground.getEnemy());
					casket = 3;
					this.playgroundView.setPlayerDestroyerAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getPlayerDestroyerAmountLabel()
																				.getText()))
									- 1));
					break;
				case 4:
					sendHitMessage(playground	.getEnemy()
												.getName()
							+ " hat einen Kreuzer versenkt");
					updateScore(15, this.playground.getEnemy());
					casket = 4;
					this.playgroundView.setPlayerCruiserAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getPlayerCruiserAmountLabel()
																				.getText()))
									- 1));
					break;
				case 5:
					sendHitMessage(playground	.getEnemy()
												.getName()
							+ " hat ein Schlachtschiff versenkt");
					updateScore(20, this.playground.getEnemy());
					casket = 5;
					this.playgroundView.setPlayerBattleshipAmountLabel(
							String.valueOf(Integer.parseInt((this.playgroundView.getPlayerBattleshipAmountLabel()
																				.getText()))
									- 1));
					break;
				default:
					break;
				}
				int randomDirection = 0;
				if (columnIndex + 1 != this.playground.getPlacementPlayer().length) {
					if (this.playground.getPlacementPlayer()[rowIndex][columnIndex + 1] == "sunk") {
						randomDirection = 3;
					}
				}
				if (columnIndex != 0) {
					if (this.playground.getPlacementPlayer()[rowIndex][columnIndex - 1] == "sunk") {
						randomDirection = 1;
					}
				}
				if (rowIndex + 1 != this.playground.getPlacementPlayer()[0].length) {
					if (this.playground.getPlacementPlayer()[rowIndex + 1][columnIndex] == "sunk") {
						randomDirection = 2;
					}
				}
				if (rowIndex != 0) {
					if (this.playground.getPlacementPlayer()[rowIndex - 1][columnIndex] == "sunk") {
						randomDirection = 4;
					}
				}
				autoPlaceBlockedWater(rowIndex, columnIndex, casket, randomDirection);
				aILastHit = "none";
				aIHorizontalShip = true;
				aIVerticalShip = true;
			}
		}
	}

	// �berpr�ft das n�chste Feld nach dem checkShipSunk
	private void checkNextShipTileEnemy(int rowIndex, int columnIndex, int exceptionRowIndex,
			int exceptionColumnIndex) {

		if (this.playground.getPlacementEnemy()[rowIndex][columnIndex] == "hit") {
			this.tileCounter.add("hit");
			if (rowIndex != this.playground.getPlacementEnemy().length - 1 && exceptionRowIndex != rowIndex + 1) {
				checkNextShipTileEnemy(rowIndex + 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != this.playground.getPlacementEnemy()[rowIndex].length - 1
					&& exceptionColumnIndex != columnIndex + 1) {
				checkNextShipTileEnemy(rowIndex, columnIndex + 1, rowIndex, columnIndex);
			}
			if (rowIndex != 0 && exceptionRowIndex != rowIndex - 1) {
				checkNextShipTileEnemy(rowIndex - 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != 0 && exceptionColumnIndex != columnIndex - 1) {
				checkNextShipTileEnemy(rowIndex, columnIndex - 1, rowIndex, columnIndex);
			}
		}

		if (this.playground.getPlacementEnemy()[rowIndex][columnIndex] != "hit"
				&& this.playground.getPlacementEnemy()[rowIndex][columnIndex] != "water"
				&& this.playground.getPlacementEnemy()[rowIndex][columnIndex] != "shot") {
			this.tileCounter.add("ship not sunk");
		}
	}

	// �berpr�ft das n�chste Feld nachdem checkShipSunk ein Feld �berpr�ft hat
	private void checkNextShipTilePlayer(int rowIndex, int columnIndex, int exceptionRowIndex,
			int exceptionColumnIndex) {

		if (this.playground.getPlacementPlayer()[rowIndex][columnIndex] == "hit") {
			this.tileCounter.add("hit");
			if (rowIndex != this.playground.getPlacementPlayer().length - 1 && exceptionRowIndex != rowIndex + 1) {
				checkNextShipTilePlayer(rowIndex + 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != this.playground.getPlacementPlayer()[rowIndex].length - 1
					&& exceptionColumnIndex != columnIndex + 1) {
				checkNextShipTilePlayer(rowIndex, columnIndex + 1, rowIndex, columnIndex);
			}
			if (rowIndex != 0 && exceptionRowIndex != rowIndex - 1) {
				checkNextShipTilePlayer(rowIndex - 1, columnIndex, rowIndex, columnIndex);
			}
			if (columnIndex != 0 && exceptionColumnIndex != columnIndex - 1) {
				checkNextShipTilePlayer(rowIndex, columnIndex - 1, rowIndex, columnIndex);
			}
		}

		if (this.playground.getPlacementPlayer()[rowIndex][columnIndex] != "hit"
				&& this.playground.getPlacementPlayer()[rowIndex][columnIndex] != "water"
				&& this.playground.getPlacementPlayer()[rowIndex][columnIndex] != "shot"
				&& this.playground.getPlacementPlayer()[rowIndex][columnIndex] != "miss") {
			this.tileCounter.add("ship not sunk");
		}

	}

	// Der Spieler schie�t auf schie�t auf seinen Gegner
	public void shootEnemy(int rowIndex, int columnIndex) {
		boolean shootAgain = false;
		Button button = (Button) getNodeFromCoordinate(this.playgroundView.getEnemyGridPane(), rowIndex, columnIndex);
		String tile = this.playground.getPlacementEnemy()[columnIndex][rowIndex];
		if (button.getStyle() != "-fx-background-color: #FF0000" && button.getStyle() != "-fx-background-color: #0000FF"
				&& button.getStyle() != "-fx-background-color: #FFFF00") {
			switch (tile) {
			case "water":
				button.setStyle("-fx-background-color: #0000FF");
				this.playground.getPlacementEnemy()[columnIndex][rowIndex] = "shot";
				sendHitMessage("Du hast nur Wasser getroffen");
				updateScore(-2, this.playground.getPlayer());
				break;
			case "ship":
				button.setStyle("-fx-background-color: #FFFF00");
				this.playground.getPlacementEnemy()[columnIndex][rowIndex] = "hit";
				sendHitMessage("Schiffstreffer!");
				updateScore(4, this.playground.getPlayer());
				shootAgain = true;
				break;
			case "shot":
				sendHitMessage("Das sollte nicht geschehen!!!");
				break;
			default:
				System.out.println("Unverhergesehenes geschehen bei der Erkennung des Feldes: " + tile);
				break;
			}

			checkShipSunkEnemy(rowIndex, columnIndex);

			if (checkWinPlayer()) {
				new Alert(Alert.AlertType.INFORMATION, this.playground	.getPlayer()
																	.getName()
						+ " hat gewonnen!", ButtonType.OK).show();
				DBUtils.insertPlayerWithHighscore(new Player(this.playground.getPlayer()
																			.getName(),
						Integer.parseInt(this.playgroundView.getCurrentScoreLabel()
															.getText()),
						Integer.parseInt(this.playgroundView.getCurrentTurnCountLabel()
															.getText())));

				backToStartView();
			} else {
				if (!shootAgain) {
					if (this.playground	.getEnemy()
										.getAI()) {
						aIAims();
					} else {

						enemyTurn();
					}
				}
			}
		} else {
			sendHitMessage("Auf dieses Feld hast du bereits geschossen.");
		}
	}

	
	private void backToStartView() {
		StartViewController startViewController = new StartViewController(new StartView());
		primaryStage.setScene(startViewController.start(this.primaryStage));
	}
	
	// Der Gegner schie�t auf den Spieler
	public void shootPlayer(int rowIndex, int columnIndex) {
		boolean shootAgain = false;
		Button button = (Button) getNodeFromCoordinate(this.playgroundView.getEnemyGridPane(), rowIndex, columnIndex);

		String tile = this.playground.getPlacementPlayer()[columnIndex][rowIndex];
		if (button.getStyle() != "-fx-background-color: #FF0000" && button.getStyle() != "-fx-background-color: #0000FF"
				&& button.getStyle() != "-fx-background-color: #FFFF00") {
			switch (tile) {
			case "water":
				button.setStyle("-fx-background-color: #0000FF");
				this.playground.getPlacementPlayer()[columnIndex][rowIndex] = "shot";
				sendHitMessage("Du hast nur Wasser getroffen");
				updateScore(-2, this.playground.getEnemy());
				break;
			case "ship":
				button.setStyle("-fx-background-color: #FFFF00");
				this.playground.getPlacementPlayer()[columnIndex][rowIndex] = "hit";
				sendHitMessage("Schiffstreffer!");
				shootAgain = true;
				updateScore(4, this.playground.getEnemy());
				break;
			case "shot":
				sendHitMessage("Das sollte nicht geschehen!!!");
				break;
			default:
				System.out.println("Unverhergesehenes geschehen bei der Erkennung des Feldes: " + tile);
				break;
			}

			checkShipSunkPlayer(rowIndex, columnIndex);

			if (checkWinEnemy()) {
				new Alert(Alert.AlertType.INFORMATION, this.playground	.getEnemy()
																	.getName()
						+ " hat gewonnen!", ButtonType.OK).show();
				backToStartView();
			} else {
				if (!shootAgain) {

					playerTurn();
				}
			}

		} else {
			sendHitMessage("Auf dieses Feld hast du bereits geschossen.");
		}

	}

	// Die KI schie�t auf den Spieler
	public void aIShootsPlayer(int rowIndex, int columnIndex) {
		boolean shootAgain = false;
		Button button = (Button) getNodeFromCoordinate(this.playgroundView.getPlayerGridPane(), rowIndex, columnIndex);

		String tile = this.playground.getPlacementPlayer()[columnIndex][rowIndex];

		switch (tile) {
		case "water":
			this.playground.getPlacementPlayer()[columnIndex][rowIndex] = "miss";
			getNodeFromCoordinate(this.playgroundView.getPlayerGridPane(), rowIndex, columnIndex).setStyle(
					"-fx-backgroundcolor: #FFFFFF");
			sendHitMessage(this.playground	.getEnemy()
											.getName()
					+ " hat ins Wasser getroffen");
			turnCount();
			updateScore(-2, this.playground.getEnemy());
			break;
		case "ship":
			button.setStyle("-fx-background-color: #FFFF00");
			this.playground.getPlacementPlayer()[columnIndex][rowIndex] = "hit";

			sendHitMessage("Schiffstreffer von " + this.playground	.getEnemy()
																	.getName()
					+ "!");
			shootAgain = true;

			updateScore(4, this.playground.getEnemy());
			break;
		default:
			System.out.println("Unverhergesehenes geschehen bei der Erkennung des Feldes: " + tile);
			break;
		}

		checkShipSunkPlayer(rowIndex, columnIndex);

		if (checkWinEnemy()) {
			new Alert(Alert.AlertType.INFORMATION, this.playground	.getEnemy()
																.getName()
					+ " hat gewonnen!", ButtonType.OK).show();
			backToStartView();
		} else {
			if (shootAgain) {
				aIAims();
			}
		}

	}

	// In dieser Methode wird die Entscheidung auf welches Feld die KI schie�t
	// bestimmt
	private void aIAims() {

		int x = (int) Math.floor(Math.random() * this.playground.getPlacementPlayer().length);
		int y = (int) Math.floor(Math.random() * this.playground.getPlacementPlayer()[0].length);
		if (aILastHit == "none") {

			if (this.playground.getPlacementPlayer()[x][y] != "miss"
					&& this.playground.getPlacementPlayer()[x][y] != "hit"
					&& this.playground.getPlacementPlayer()[x][y] != "sunk") {
				if (this.playground.getPlacementPlayer()[x][y] == "ship") {
					aILastHit = x + ":" + y;
				}
				aIShootsPlayer(y, x);
			} else {
				aIAims();
			}
		} else {
			aIAimsCarefully();
		}
	}

	// Diese Methode l�sst die KI nach einem Treffer �berlegen wo
	// sie als n�chstes hin schie�t. Dies passiert nicht mehr zuf�llig
	private void aIAimsCarefully() {
		int x = Integer.parseInt(aILastHit.split(":")[0]);
		int y = Integer.parseInt(aILastHit.split(":")[1]);

		if (this.playground.getPlacementPlayer()[x][y] == "ship") {
			aIShootsPlayer(y, x);
		} else if (y != this.playground.getPlacementPlayer()[0].length - 1
				&& this.playground.getPlacementPlayer()[x][y + 1] != "miss"
				&& this.playground.getPlacementPlayer()[x][y + 1] != "hit"
				&& this.playground.getPlacementPlayer()[x][y + 1] != "sunk" && this.aIVerticalShip) {
			if (this.playground.getPlacementPlayer()[x][y + 1] == "ship") {
				this.aIHorizontalShip = false;
				aILastHit = x + ":" + (y + 1);
			} else {
				if (!(this.aIVerticalShip && this.aIHorizontalShip)) {

					for (int i = 1; true; i++) {
						if (y - i >= 0) {
							if (this.playground.getPlacementPlayer()[x][y - i] == "ship") {
								aILastHit = x + ":" + (y - i);
								break;
							}
						}
					}
				}
			}
			aIShootsPlayer(y + 1, x);

		} else if (y != 0 && this.playground.getPlacementPlayer()[x][y - 1] != "miss"
				&& this.playground.getPlacementPlayer()[x][y - 1] != "hit"
				&& this.playground.getPlacementPlayer()[x][y - 1] != "sunk" && this.aIVerticalShip) {

			if (this.playground.getPlacementPlayer()[x][y - 1] == "ship") {
				this.aIHorizontalShip = false;
				aILastHit = x + ":" + (y - 1);
			} else {
				if (!(this.aIVerticalShip && this.aIHorizontalShip)) {
					for (int i = 1; true; i++) {
						if (y + i < this.playground.getPlacementPlayer()[0].length) {
							if (this.playground.getPlacementPlayer()[x][y + i] == "ship") {
								aILastHit = x + ":" + (y + i);
								break;
							}
						}
					}
				}
			}
			aIShootsPlayer(y - 1, x);

		} else if (x != this.playground.getPlacementPlayer().length - 1
				&& this.playground.getPlacementPlayer()[x + 1][y] != "miss"
				&& this.playground.getPlacementPlayer()[x + 1][y] != "hit"
				&& this.playground.getPlacementPlayer()[x + 1][y] != "sunk" && this.aIHorizontalShip) {

			if (this.playground.getPlacementPlayer()[x + 1][y] == "ship") {
				this.aIVerticalShip = false;
				aILastHit = (x + 1) + ":" + y;
			} else {
				if (!(this.aIVerticalShip && this.aIHorizontalShip)) {

					for (int i = 1; true; i++) {
						if (x - i >= 0) {
							if (this.playground.getPlacementPlayer()[x - i][y] == "ship") {
								aILastHit = (x - i) + ":" + y;
								break;
							}
						}
					}
				}
			}
			aIShootsPlayer(y, x + 1);

		} else if (x != 0 && this.playground.getPlacementPlayer()[x - 1][y] != "miss"
				&& this.playground.getPlacementPlayer()[x - 1][y] != "hit"
				&& this.playground.getPlacementPlayer()[x - 1][y] != "sunk" && this.aIHorizontalShip) {

			if (this.playground.getPlacementPlayer()[x - 1][y] == "ship") {
				this.aIVerticalShip = false;
				aILastHit = (x - 1) + ":" + y;
			} else {
				if (!(this.aIVerticalShip && this.aIHorizontalShip)) {

					for (int i = 1; true; i++) {
						if (x + i < this.playground.getPlacementPlayer().length) {
							if (this.playground.getPlacementPlayer()[x + i][y] == "ship") {
								aILastHit = (x + i) + ":" + y;
								break;
							}
						}
					}
					aIShootsPlayer(y, x - 1);
				}
			}
		}
	}

	public void autoPlaceBlockedWater(int randomX, int randomY, int casket, int randomDirection) {
		int x = randomX;
		int y = randomY;
		String[][] placement = this.playground.getPlacementPlayer();
		if (randomDirection == 2) { // rechts
			for (int i = -1; i < casket + 1; i++) {
				if ((x + i >= 0 && y - 1 >= 0) && (x + i < placement.length && y - 1 < placement[x + i].length)) {
					placement[x + i][y - 1] = "miss";
				}
				if ((x + i >= 0 && y + 1 >= 0) && (x + i < placement.length && y + 1 < placement[x + i].length)) {
					placement[x + i][y + 1] = "miss";
				}
			}
			if ((x - 1 >= 0 && y >= 0) && (x - 1 < placement.length && y < placement[x - 1].length)) {
				placement[x - 1][y] = "miss";

			}
			if ((x + casket >= 0 && y >= 0) && (x + casket < placement.length && y < placement[x + casket].length)) {
				placement[x + casket][y] = "miss";
			}
		}
		if (randomDirection == 4) { // links
			for (int i = 1; i > -(casket + 1); i--) {
				if ((x + i >= 0 && y - 1 >= 0) && (x + i < placement.length && y - 1 < placement[x + i].length)) {
					placement[x + i][y - 1] = "miss";

				}
				if ((x + i >= 0 && y + 1 >= 0) && (x + i < placement.length && y + 1 < placement[x + i].length)) {
					placement[x + i][y + 1] = "miss";
				}
			}
			if ((x + 1 >= 0 && y >= 0) && (x + 1 < placement.length && y < placement[x + 1].length)) {
				placement[x + 1][y] = "miss";
			}

			if ((x - casket >= 0 && y >= 0) && (x - casket < placement.length && y < placement[x - casket].length)) {
				placement[x - casket][y] = "miss";
			}
		}
		if (randomDirection == 3) { // unten
			for (int i = -1; i < casket + 1; i++) {
				if ((x + 1 >= 0 && y + i >= 0) && (x + 1 < placement.length && y + i < placement[x + 1].length)) {
					placement[x + 1][y + i] = "miss";
				}
				if ((x - 1 >= 0 && y + i >= 0) && (x - 1 < placement.length && y + i < placement[x - 1].length)) {
					placement[x - 1][y + i] = "miss";
				}
			}
			if ((x >= 0 && y - 1 >= 0) && (x < placement.length && y - 1 < placement[x].length)) {
				placement[x][y - 1] = "miss";
			}
			if ((x >= 0 && y + casket >= 0) && (x < placement.length && y + casket < placement[x].length)) {
				placement[x][y + casket] = "miss";
			}
		}
		if (randomDirection == 1) { // oben
			for (int i = 1; i > -(casket + 1); i--) {
				if ((x + 1 >= 0 && y + i >= 0) && (x + 1 < placement.length && y + i < placement[x + 1].length)) {
					placement[x + 1][y + i] = "miss";
				}
				if ((x - 1 >= 0 && y + i >= 0) && (x - 1 < placement.length && y + i < placement[x - 1].length)) {
					placement[x - 1][y + i] = "miss";
				}
			}
			if ((x >= 0 && y + 1 >= 0) && (x < placement.length && y + 1 < placement[x].length)) {
				placement[x][y + 1] = "miss";
			}
			if ((x >= 0 && y - casket >= 0) && (x < placement.length && y - casket < placement[x].length)) {
				placement[x][y - casket] = "miss";
			}
		}
	}

	// Wechselt die Ansicht zu der des Spielers
	private void playerTurn() {
		turnCount();
		this.playgroundView.createIntermediateViewToPlayer();
		this.playersTurn = true;
		this.intermediate = true;
		updateScore(0, this.playground.getPlayer());

	}

	// Wechselt die Ansicht zu der des Gegners
	private void enemyTurn() {

		this.playgroundView.createIntermediateViewToEnemy();
		this.playersTurn = false;
		this.intermediate = true;
		updateScore(0, this.playground.getEnemy());

	}

	// Stellt das Ergebnis der letzten Aktion in einem Label fest
	public void sendHitMessage(String message) {
		playgroundView	.getGameMessageLabel()
						.setText(message);
	}

	// Setzt den Rundenz�hler um 1 weiter
	public void turnCount() {
		playgroundView.setCurrentTurnCountLabel(
				String.valueOf(Integer.parseInt(playgroundView	.getCurrentTurnCountLabel()
																.getText())
						+ 1));
	}

	// Startet den Z�hler f�r das Spiel
	public void playingTime() {
		TotalTimeThread totalTimeThread = new TotalTimeThread(this.playgroundView);
		totalTimeThread.start();
	}

	// Z�hler f�r die Zeit
	public void updateTime() {
		int minutes = 0;
		int seconds = 0;
		while (true) {
			this.playgroundView	.getCurrentPlayTimeLabel()
								.setText(minutes + ":" + seconds);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			seconds++;
			if (seconds == 60) {
				minutes++;
				seconds = 0;
			}
		}
	}

	// Aktualisiert die Punkteanzahl nach einem Schuss
	public void updateScore(int points, Player player) {
		player.setScore((player.getScore() + points));
		if (this.playground	.getEnemy()
							.getName() != "Computer") {
			this.playgroundView.setCurrentScoreLabel(String.valueOf(player.getScore()));
		}
	}

	// Gibt true oder false wieder, je nachdem ob der Spieler noch Schiffe besitzt
	// Sollte dazu benutzt werden um zu gucken ob der Gegner gewinnt!!!
	public boolean checkWinEnemy() {
		boolean result = true;
		if (Integer.parseInt(playgroundView	.getPlayerBattleshipAmountLabel()
											.getText()) != 0
				|| Integer.parseInt(playgroundView	.getPlayerDestroyerAmountLabel()
													.getText()) != 0
				|| Integer.parseInt(playgroundView	.getPlayerCruiserAmountLabel()
													.getText()) != 0
				|| Integer.parseInt(playgroundView	.getPlayerSubmarineAmountLabel()
													.getText()) != 0) {
			result = false;
		}
		return result;
	}

	// Gibt true oder false wieder, je nachdem ob der Gegner noch Schiffe besitzt
	// Sollte dazu benutzt werden um zu gucken ob der Spieler gewinnt!!!
	public boolean checkWinPlayer() {
		boolean result = true;
		if (Integer.parseInt(playgroundView	.getEnemyBattleshipAmountLabel()
											.getText()) != 0
				|| Integer.parseInt(playgroundView	.getEnemyDestroyerAmountLabel()
													.getText()) != 0
				|| Integer.parseInt(playgroundView	.getEnemyCruiserAmountLabel()
													.getText()) != 0
				|| Integer.parseInt(playgroundView	.getEnemySubmarineAmountLabel()
													.getText()) != 0) {
			result = false;
		}

		return result;
	}

	// Holt einen Node aus einer GridPane, wenn man ihr die Koordinaten �bergibt
	public Node getNodeFromCoordinate(GridPane gridPane, int rowIndex, int columnIndex) {
		for (Node node : gridPane.getChildren()) {
			if (GridPane.getRowIndex(node) == rowIndex && GridPane.getColumnIndex(node) == columnIndex) {
				return node;
			}
		}
		return null;
	}

	private int getRowIndexOfButton(Button button) {
		return GridPane.getRowIndex(button);
	}

	private int getColumnIndexOfButton(Button button) {
		return GridPane.getColumnIndex(button);
	}

	// Muss noch eingebaut werden
	public void createLabelText() {
		this.playgroundView	.getPlayerSiteLabel()
							.setText("Deine Schiffe: " + this.playground.getPlayer()
																		.getName());
		this.playgroundView	.getEnemySiteLabel()
							.setText("Gegnerische Schiffe von: " + this.playground	.getEnemy()
																					.getName());
	}

}
